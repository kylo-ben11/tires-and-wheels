<?php
$PageMetaTitle = 'Wheel and Tire Packages at TiresAndWheels.com';
$PageMetaDesc = 'Wheel and Tire Packages at cheap prices! FREE mounting, balancing, shipping (Contl USA) and lug nuts! All top name brands available!';
$PageMetaKeyW = 'Tires and Wheels,Tires,Wheels,Wheel And Tire Packages,Offroad Accessories,Lift Kits';
$Page = 'packages';
$PageClass = 'packages-page';
$HeroTitle = 'Package Builder';
include ('includes/header.php');

if ( GetCurVid() ) {
  echo"
  <script>
    window.location.href = '/wheel-results.php'
  </script>";
}

$appguide_action = 'wheel-results.php';
include ('includes/app-guide.php');
?>

<div class="container inner-content" id="main">
  <div class="row">
    <div class="twelve">

      <div class="featured-title">Start With A Wheel</div>
      <p>We mount, balance and ship for free!</p>

      <div class="clear"></div>

      <div class="wheel-search-selection">
        <h3>Vehicle</h3>
        <a href="#" data-role="target-app-guide" class="highlight-app-guide button">Select Year Above</a>   
      </div>

      <div id="bp-select-box" class="wheel-search-selection">
        <h3>Bolt Pattern</h3>
      <?php 
        $storeid = 4;
        $width = 0;
        $bolt 	= $_GET['bc'];

        $BoltArray 	= WheelUniqueBoltArray ( $storeid );

        echo "
        <form name=search action='wheel-results.php'>
        
          <select name='bc' OnChange=submit()>
            <option value=''>Choose a Bolt Pattern</option>";
            if ( is_array( $BoltArray ) ) :
              foreach($BoltArray as $val ){
                echo " 
                <option value='$val'".ilif($val,$_GET['bc']," SELECTED",'').">$val</option>";
              }
            endif;
          echo "
          </select>
        </form>";

        $RESULT	= WheelResultArrayMax ($storeid,$bolt,$minsize,$maxsize,$minwidth,$maxwidth,$minoffset,$maxoffset,$minhub,$maxhub,$minload,$maxload,$finish,$construction,$brand,$invlimitone,$featurelimit,$perpage,$curpage,$sort);
      ?>
      </div>

      <div class="wheel-search-selection">
        <h3>Brand</h3>
        <a href="brands.php?btype=10" class="button">Shop by brand</a>
      </div>

    </div>
    <div class="clear"></div>
    
    <img src="/images/mount-balance-ship.png" alt="Mounting, Balancing, Shipping - Wheel and Tire Packages" title="Mounting, Balancing, Shipping - Wheel and Tire Packages" />

  </div>
</div>

<?php
include ('includes/footer.php'); ?>