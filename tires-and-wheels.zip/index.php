
<?php

$Page = 'home';
$PageClass = 'home-page';
include ('includes/header.php');

$appguide_action = 'wheel-results.php';
include 'includes/app-guide-hero.php';
?>



<section class="content content_filters" id="search_filters">


<?php if (GetCurVid()) { ?>

      <!-- <h1>Testing...Is this thing on?</h1>
      <p>What are you shopping for?</p>

      <div class="hero-boxes">
        <div class="hero-feature" id="hero-box-tires">
          <a href="/tires.php"><img src="images/shop-tires.png" alt="Shop for Tires" title="Shop for Tires" /></a>
        </div>
        <div class="hero-feature" id="hero-box-wheels">
          <a href="/wheels.php"><img src="images/shop-wheels.png" alt="Shop for Wheels" title="Shop for Wheels" /></a>
        </div>
        <div class="hero-feature" id="hero-box-package">
          <a href="/packages.php"><img src="images/package-builder.png" alt="Package Builder" title="Package Builder" /></a>
        </div>
      </div> -->

<?php } else { ?>

  <div class="filter filter_vehicle" id="hero-box-app-guide">
      <h2>Enter Your Vehicle</h2>

      <!-- <div class="hero-boxes">
        <div class="hero-search" id="hero-box-app-guide">
          <h2>Enter Your Vehicle</h2> -->

          <form id="advanced-search-form" action="<?=$appguide_action;?>" method="get">
            <?php
            if ( is_numeric( $_GET['item_id'] ) ):
              echo "
              <input type=hidden name='item_id' value='".$_GET['item_id']."'>";
            endif;

            if ( is_numeric( $_GET['cat_id'] ) ):
              echo "
              <input type=hidden name='cat_id' value='".$_GET['cat_id']."'>";
            endif;

            if ( is_numeric( $_GET['scat_id'] ) ):
              echo "
              <input type=hidden name='scat_id' value='".$_GET['scat_id']."'>";
            endif;

            $yeararry = GetYearArray();

            echo "<select id='home-year-select' name='c-year'><option value=''>Year</option>";

              if(is_array($yeararry)){
                foreach($yeararry as $year) {
                  echo "<option value='".$year."'".ilif($_GET['year'],$year," SELECTED",'').">".$year."</option>";
                }
              }
            ?>
            </select>
            <select id="home-make-select" name="c-make"><option value="">Make</option></select>
            <select id="home-model-select" name="c-model"><option value="">Model</option></select>
            <select id="home-vid-select" name="c-vid"><option value="">Sub Model</option></select>
            <div class="clear"></div>
          </form>
        </div>

        <div class="filter filter_wheels hero-search" id="hero-box-wheels">
          <h2>Shop For Wheels</h2>
          <?php
            $storeid = 4;
            $width = 0;
            $bolt 	= $_GET['bc'];
            $BoltArray 	= WheelUniqueBoltArray ( $storeid );

            echo "
            <form name=search action='wheel-results.php'>
              <select name='bc' OnChange=submit()>
              <option value=''>Choose a Bolt Pattern</option>";
              if ( is_array( $BoltArray ) ) :
                foreach($BoltArray as $val ) {
                  echo "<option value='$val'".ilif($val,$_GET['bc']," SELECTED",'').">$val</option>";
                }
              endif;
              echo "
              </select>
            </form>";

            $RESULT	= WheelResultArrayMax ($storeid,$bolt,$minsize,$maxsize,$minwidth,$maxwidth,$minoffset,$maxoffset,$minhub,$maxhub,$minload,$maxload,$finish,$construction,$brand,$invlimitone,$featurelimit,$perpage,$curpage,$sort);
          ?>
          <div class="png_container top"></div>

           <img id="filter-rim" src="images/mojave-v2.png" alt="Shop for Wheels" title="Shop for Wheels" />

        </div>

        <div class="filter filter_tires hero-search" id="hero-box-tires">
          <h2>Shop For Tires</h2>
          <?php
            $storeid = 4;
            $width = 0;
            $dim = $_GET['mntsize'];
            $DimArray = TireDIMUniqueArrayMax ($storeid,$width,$minod,$maxod,$mincs,$maxcs,$minas,$maxas,$serv,$speed,$rating,$load,$brand,$sw,$invlimitone,$featurelimit);
            echo "
            <form name=search action='tire-results.php'>
              <select name='mntsize' OnChange=submit()>
                <option value=''>Choose a Size</option>";
                if ( is_array( $DimArray ) ) :
                  foreach($DimArray as $val ){
                    echo "
                    <option value='$val'".ilif($val,$_GET['mntsize']," SELECTED",'').">$val</option>";
                  }
                endif;
              echo "
              </select>
            </form>";
            $RESULT = StockWheelToVechMaxArray (4,GetCurVid ( ),$_GET['finish'],$_GET['construction'],$_GET['brand'],$_GET['minrim'],$_GET['maxrim'],$_GET['minwidth'],$_GET['maxwidth'],$_GET['minoffset'],$_GET['maxoffset'],$perpage,$_GET['s-page'],$_GET['sort'],$stklimit,$featured ) ;
          ?>
          <div class="png_container top"></div>

              <img id="filter-tire" src="images/tire-wheel.png" alt="Shop for Tires" title="Shop for Tires" />

        </div>

      <div class="clear"></div>

<?php } ?>

    </div>
    <!-- <div class="clear"></div>
  </div>
</div> -->

<!-- <div class="mobile-hero-boxes">
  <a href="/tires.php" class="mobile-feature" id="mobile-box-tires" title="Shop for Tires" >Shop Tires</a>
  <a href="/wheels.php" class="mobile-feature" id="mobile-box-wheels" title="Shop for Wheels">Shop Wheels</a>
  <a href="/packages.php" class="mobile-feature" id="mobile-box-package" title="Package Builder">Package Builder</a>
</div> -->

<!-- <div class="blue-divider"></div> -->

<?php if (GetCurVid()) { ?>
<div class="container" id="search-vehicle">
  <div class="row">
    <div class="twelve last">
      <?php
        $cyear  = GetModelYear($vid);
        $cmake  = GetModelMake($vid);
        $cmodel = GetModelName($vid);
        $csub   = GetModelSub($vid);

        $full_name = $cyear . " " . $cmake . " " . $cmodel . " " . $csub;
      ?>
      <div id="search-vehicle-text">
        <span id="vid-str">
          <strong>VEHICLE:</strong>
          <?=$full_name;?>
          <a href="<?=$appguide_reset;?>">[reset vehicle]</a>
        </span>
        <span id="show-form"><a href="#">Filter Results</a></span>
      </div>
    </div>
    <div class="clear"></div>
  </div>
</div>

<?php } ?>
</section>


<section class="content content_callouts flex-column">
  <div class="content_callouts--cnc">
    <div class="shape">
      <div class="texture"></div>
      <div class="callout callout--cnc" data-aos="fade-up" data-aos-easing="ease" data-aos-duration="500">
        <div class="callout-title">
          CNC Machines Now Drilling
        </div>
        <div class="callout-text">
          <p>Custom wheel offsets, bolt patterns, and hub bores!</p>
          <p>Blank wheels always in-stock!</p>
        </div>
      </div>

    </div>
  </div>
  <div class="content_callouts--inStock">
    <div class="shape">
      <div class="texture"></div>
      <div class="callout callout--inStock" data-aos="fade-up-left" data-aos-easing="ease" data-aos-duration="500">
        <div class="callout-title">
          Thousands of Tires &amp; Wheels In-Stock!
        </div>
        <div class="callout-text">
          Join Team Extreme and show off your ride on Lifted Truck Club!
        </div>
        <div class="feature_buttons feature_buttons--inStock">
          <a class="feature_button feature_button_left animated" href="tires.php" target="_blank">Shop Tires</a> <a class="feature_button feature_button_right animated" href="wheels.php" target="_blank">Shop Wheels</a>
        </div>
      </div>

    </div>
  </div>
  <div class="content_callouts--package">
    <div class="shape">
      <div class="texture"></div>
      <div class="callout callout--package" data-aos="fade-up-right" data-aos-easing="ease" data-aos-duration="500">
        <div class="callout-title">
          Free Mounting, Balancing, Lug Nuts &amp; Shipping When You Buy a Package!
        </div>
        <div class="callout-text">
          Join Team Extreme and show off your ride on Lifted Truck Club!
        </div>
        <div class="feature_buttons feature_buttons--package">
          <a href="packages.php" class="feature_button animated">Build a Package</a>
        </div>
      </div>
    </div>

  </div>
</section>





















<!-- <div class="container" id="main">
  <div class="row">
<?php /*
    <a href="http://www.extremecustoms.com/giveaway.php" class="home-banner">
      <img src="/images/banner-truck-build.jpg">
    </a>

    <a href="http://www.extremecustoms.com/giveaway.php" class="home-banner-mobile">
      <img src="/images/banner-truck-build-mobile.jpg">
    </a>
*/ ?>
    <div class="home-feature" id="home-cnc">
      <div class="six">
        <h3>CNC Machines<br> Now Drilling</h3>
        <p>Custom Offset Wheels,<br> Bolt Patterns & Hub Bores!</p>
        <p>Blank Wheels Always In-Stock!</p>
      </div>
      <a class="feature-link fl-cnc six last" href="/wheels.php" alt="Now Drilling"></a>
      <div class="clear"></div>
    </div>

    <div class="home-feature" id="home-in-stock">
      <h3>Thousands of Tires &amp; Wheels In-Stock!</h3>
      <a class="feature-link fl-tires six" href="/tires.php" alt="Shop Tires">
        <div class="feature-link-overlay">
          <span class="feature-link-icon sprite"></span>
          <h4>Shop Tires</h4>
        </div>
      </a>
      <a class="feature-link fl-wheels six last" href="/wheels.php" alt="Shop Wheels">
        <div class="feature-link-overlay">
          <span class="feature-link-icon sprite"></span>
          <h4>Shop Wheels</h4>
        </div>
      </a>
      <div class="clear"></div>
    </div>

    <div class="home-feature" id="home-packages">
      <div class="twelve">
        <h3>free mounting, balancing, lug nuts &amp;<br> shipping when you buy a package!</h3>

        <a class="feature-link fl-packages" href="/packages.php" alt="Build A Package">
          <div class="feature-link-overlay">
            <span class="feature-link-icon sprite"></span>
            <h4>Build a Package</h4>
          </div>
        </a>
      </div>
      <div class="clear"></div>
    </div>

  </div>
</div> -->

<?php /*

<div class="container" id="home-banner">
  <div class="row">
    <div class="twelve">

      <h2>We Mount, Balance, Ship and you save 5% to 25% on a package!</h2>

    </div>
    <div class="clear"></div>
  </div>
</div>

*/ ?>

<?php
include ('includes/footer.php'); ?>
