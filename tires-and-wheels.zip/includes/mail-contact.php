<?php 
if(isset($_POST['submit-form'])){

  $to      = "brian.kikendall@gmail.com";
  $from    = $_POST['email'];
  $subject = "TW.com Contact Form Message";

  $name    = $_POST['name'];
  $phone   = $_POST['phone'];
  $comment = $_POST['message'];

  $message = "
    Name:  " .$name. "
    Email: " .$from."
    Phone: " .$phone."
    Message: " .$comment;

  $headers = "From:" . $from;
  mail($to,$subject,$message,$headers);

}
?>