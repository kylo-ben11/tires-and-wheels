<script type="text/javascript">
jQuery(document).ready(function($) {
  $('#logo-slides').slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    arrows: false,
    autoplay: true,
    autoplaySpeed: 3000
  });
});
</script>


<div id="sticky-footer" class="container">
  <div class="row">

    <div id="mobile-footer-wrap">
      <a class="footer-phone-mobile" href="tel:8882584737">
        <div class="phone-icon-mobile sprite"></div>
      </a>
      <div class="footer-separator"><span class="sprite"></span></div>
      <a class="footer-email-mobile" href="mailto:info@extremecustoms.com">
        <div class="email-icon-mobile sprite"></div>
      </a>
      <div class="footer-separator"><span class="sprite"></span></div>
      <div class="mobile-chat-notification">
        <div id="mobile-chat-online" class="sprite chat-notification"></div>
        <div id="mobile-chat-offline" class="sprite chat-notification"></div>
      </div>
    </div>

    <div id="footer-wrap">
      <div class="footer-contact-info">
        <a class="footer-phone" href="tel:8882584737">
          <div class="phone-icon sprite"></div>
          <span>888.258.4737</span>
        </a>
      </div>

      <div class="footer-separator sprite"></div>

      <div class="footer-contact-info">
        <a class="footer-email" href="mailto:info@tiresandwheels.com">
          <div class="email-icon sprite"></div>
          <span>Email Us</span>
        </a>
      </div>

      <div class="footer-separator sprite"></div>

      <div id="chat-online" class="sprite chat-notification"></div>
      <div id="chat-offline" class="sprite chat-notification"></div>

      <div class="footer-separator sprite"></div>

      <div id="footer-social-icons">
        <a href="https://www.facebook.com/tiresandwheelsdotcom" target="_blank"><i class="fab fa-facebook-square fa-2x"></i></a>
        <!-- <a id="sm-linkedin" href="https://www.linkedin.com/company/extremecustoms" target="_blank"></a> -->
        <a id="sm-youtube" href="https://www.youtube.com/user/ExtremeCustomsTV" target="_blank"><i class="fab fa-youtube-square fa-2x"></i></a>
        <a id="sm-twitter" href="http://www.twitter.com/ExtremeCustoms" target="_blank"><i class="fab fa-twitter-square fa-2x"></i></a>
        <a id="sm-instagram" href="https://www.instagram.com/tires_and_wheels/" target="_blank"><i class="fab fa-instagram fa-2x"></i></a>
      </div>

      <div class="footer-separator sprite"></div>

      <a id="footer-bbb-icon" style="background: url(<?php echo ilif(is_secure(),true,'https','http');?>://seal-wisconsin.bbb.org/seals/blue-seal-200-42-whitetxt-tire-reps-llc-1000012499.png);" href="http://www.bbb.org/wisconsin/business-reviews/wheels/tire-reps-llc-in-oshkosh-wi-1000012499/#bbbonlineclick" target="_blank"></a>
    </div>

  </div>
</div>

<?php include_once ('affirm/affirm.js.php'); ?>

<script type='text/javascript' src='/includes/lightbox2/js/lightbox.min.js'></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-73944229-1', 'auto');
  ga('send', 'pageview');

</script>
<!-- Scripts -->
<script src="scripts/index.js"></script>
<script>
$(document).ready(function(){
  $(".hamburger").click(function(){
    $(this).toggleClass("is-active");
  });
  $(".hamburger").click(function(){
  $('#mobile-navigation').slideToggle(500);
});
});
  //Shards animation
  $(window).scroll(function() {
    var scroll = $(window).scrollTop();
    $(".filter_wheels .png_container").css({
      transform: 'scale(' + (100 + scroll / 5) / 100 + ')',

    });
  });


  $(window).scroll(function() {
    var scroll = $(window).scrollTop();
    $("#filter-rim").css({
      transform: 'scale(' + (100 + scroll / 15) / 100 + ')',
    });
  });

  $(window).scroll(function() {
    var scroll = $(window).scrollTop();
    $(".filter_tires .png_container").css({
      transform: 'scale(' + (100 + scroll / 5) / 100 + ')',

    });
  });


  // $(window).scroll(function() {
  //   var scroll = $(window).scrollTop();
  //   $(".filter_tires img").css({
  //     transform: 'scale(' + (100 + scroll / 15) / 100 + ')',
  //   });
  // });

  $(window).scroll(function(){
    var scroll = $(window).scrollTop();
    $("#filter-tire").addClass('animated bounce');
  })

  var position = $(window).scrollTop();

  // should start at 0

  $(window).scroll(function() {
    var scroll = $(window).scrollTop();
    if (scroll > position) {

      $('.navigation_bar--sticky').css({
        transform: 'translateY(-40px)',
        transition: '0.25s',
        height: '80px',
      });
    } else {

      $('.navigation_bar--sticky').css({
        transform: 'translateY(0px)',
        transition: '0.25s',
        height: '100px',
      });
    }
    position = scroll;
  });

  var position_mobile = $(window).scrollTop();

  // should start at 0

  $(window).scroll(function() {
    var scroll_mobile = $(window).scrollTop();
    if (scroll_mobile > position_mobile) {

      $('#mobile-navigation').css({
        "margin-top": "-20px"
      });
    } else {

      $('#mobile-navigation').css({
        "margin-top": "0px"
      });
    }
    position_mobile = scroll_mobile;
  });
  //
  // var position_hamburger = $(window).scrollTop();
  //
  // $(window).scroll(function() {
  //   var scroll_hamburger = $(window).scrollTop();
  //   if (scroll_hamburger > position_hamburger) {
  //
  //     $('#hamburger-9').css({
  //       transform: 'scale(0.55)',
  //       transition: '0.25s',
  //     });
  //   } else {
  //
  //     $('#hamburger-9').css({
  //       transform: 'scale(1.0)',
  //       transition: '0.25s',
  //     });
  //   }
  //   position_hamburger = scroll_hamburger;
  // });


  var position_logo = $(window).scrollTop();

  $(window).scroll(function() {
    var scroll_logo = $(window).scrollTop();
    if (scroll_logo > position_logo) {

      $('#logo img').css({
        transform: 'scale(0.8)',
        transition: '0.25s',
      });
    } else {

      $('#logo img').css({
        transform: 'scale(1.0)',
        transition: '0.25s',
      });
    }
    position_logo = scroll_logo;
  });

  $('.feature_button').hover(function() {
    $(this).addClass('swing');
},
function() {
  $(this).removeClass('swing');
})
</script>
<script>
  AOS.init();
</script>

</body>
</html>
