<?php
function get_hidden_inputs($except) {
  $o = '';
  foreach($_GET as $k => $v) {
    if(in_array($k, $except)) continue;
    $o .= '<input type="hidden" name="'.$k.'" value="'
      .htmlspecialchars($v, ENT_QUOTES)
      .'">';
  }
  return $o;
}

$vid = GetCurVid();

if(!isset($appguide_prompt)) {
  $appguide_prompt = 'Let&#39;s Get Rolling! Start Here';
}

if(!isset($appguide_action)) {
  $appguide_action = '';
}

if(!isset($appguide_reset)) {
  $appguide_reset = '?c-vid=0';
}

$cyear  = GetModelYear($vid);
$cmake  = GetModelMake($vid);
$cmodel = GetModelName($vid);
$csub   = GetModelSub($vid);

$full_name = $cyear . " " . $cmake . " " . $cmodel . " " . $csub;
?>