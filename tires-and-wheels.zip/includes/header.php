<?php
include_once ('inc.store/ssc.new.api.php');

$RegPUCookieName = "CookieRegisterPopup";
$RegPUCookieVal  = "Popup Enabled";
setcookie($RegPUCookieName, $RegPUCookieVal, time() + 14400 );

$VerTrackCS = 'css/style.css';
$VerTrackJS  = 'js/site.js';
$csVer = "?v=".date ("ymdHis", filemtime($VerTrackCS));
$jsVer = "?v=".date ("ymdHis", filemtime($VerTrackJS));

$CartCount = GetCartCount('RWD');

if( $Page != 'client' && $Page != 'review' && $HeroTitle != 'Order Review' && $Page != 'offer' && $Page != 'return' && $Page != 'thank-you' ):
if(function_exists('SetCurVid')) {
  if(array_key_exists('c-vid',$_GET)) {
   SetCurVid($_GET['c-vid']);
  } else {
    if($vid = GetCurVid()) {
      $_GET['c-vid'] = $vid;
      header('Location: '.$_SERVER['SCRIPT_URI'].'?'.http_build_query($_GET));
      echo 'VID Required. Redirecting...';
      exit();
    }
  }
}
endif;

if(!isset($PageMetaTitle)) {
  $PageMetaTitle = 'Tires And Wheels - Tire Reps & Extreme Customs';
}

if(!isset($PageMetaDesc)) {
  $PageMetaDesc = 'TiresAndWheels.com is now part of the Extreme Customs Online Network! We also teamed up with Tire Reps to get tires and wheels at the best prices! Wheel and tire packages are also available!';
}

if(!isset($PageMetaKeyW)) {
  $PageMetaKeyW = 'tires and wheels,extreme customs,extreme customs oshkosh,extreme customs llc,extreme customs wisconsin,tire reps,tire reps Oshkosh,tire reps wisconsin,wheel and tire packages,tires for sale,wheels for sale,rims for sale,cheap tires,cheap wheels';
}

$PageURL = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

if(!isset($PageImage) || $PageImage == '') {
  $PageImage = 'http://www.tiresandwheels.com/images/tires-and-wheels.jpg';
}
?>
<!DOCTYPE html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta charset="UTF-8" />

<title><?=$PageMetaTitle;?></title>

<meta name='Description' content='<?=$PageMetaDesc;?>' />
<meta name='Keywords' content='<?=$PageMetaKeyW;?>' />

<meta property="og:url" content="<?=$PageURL;?>" />
<meta property="og:type" content="website" />
<meta property="og:site_name" content="Tires and Wheels" />
<meta property="og:title" content="<?=$PageMetaTitle;?>" />
<meta property="og:image" content="<?=$PageImage;?>" />
<meta property="og:description" content="<?=$PageMetaDesc;?>" />

<link href="/images/favicon.ico" rel="icon" type="image/x-icon" />
<link href="/images/favicon.png" rel="icon" type="image/png" />
<link href="/images/apple-touch-icon.png" rel="apple-touch-icon" sizes="180x180" />
<link href="/images/icon-hires.png" rel="icon" sizes="192x192" />

<link rel='stylesheet' href='/css/font.css' type='text/css' media='all' />
<link rel='stylesheet' href='/css/style.css<?=$csVer;?>' type='text/css' media='all' />
<link rel='stylesheet' href='/css/responsive.css<?=$csVer;?>' type='text/css' media='all' />
<link rel='stylesheet' href='/includes/lightbox2/css/lightbox.css' type='text/css' media='all' />
<link rel='stylesheet' href='/includes/slick/slick.css' type='text/css' media='all' />
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

<script type='text/javascript' src='/js/jquery.js'></script>
<script type='text/javascript' src='/js/jquery-migrate.min.js'></script>
<script type='text/javascript' src='/js/jquery.placeholder.min.js'></script>
<script type='text/javascript' src='/js/site.js<?=$jsVer;?>'></script>
<script type='text/javascript' src='/includes/slick/slick.min.js'></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<?php
if ( is_array ( $AddJs ) ) {
  foreach ( $AddJs as $key=>$val ) {
    echo "<script type='text/javascript' src='".$val."'></script>";
  }
}
?>

<!-- Start of Zopim Live Chat Script-->
<script type="text/javascript">
  window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
  d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
  _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
  $.src="//v2.zopim.com/?2WAwGFtrtnxgu1BdKAu9lX6Bm0W1BVIF";z.t=+new Date;$.
  type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
</script>

<script type="text/javascript">
jQuery(document).ready(function($) {

  $zopim(function(){
    $zopim.livechat.setOnStatus(statusHandler);

    function statusHandler(status){
      if(status=='online') {
        // Online
        // Don't need to change the button
        $("#chat-online, #mobile-chat-online").css('display', 'block');
        $("#chat-offline, #mobile-chat-offline").css('display', 'none');
      }
      else if(status=='away') {
        // Away
        // Switch button button at the bottom of the screen to say offline (#live-chat-notification)
        $("#chat-offline, #mobile-chat-offline").css('display', 'none');
        $("#chat-online, #mobile-chat-online").css('display', 'block');
      }
      else if(status=='offline') {
        // Offline
        // Switch the button at the bottom of the screen to say offline (#live-chat-notification)
        $("#chat-offline, #mobile-chat-offline").css('display', 'block');
        $("#chat-online, #mobile-chat-online").css('display', 'none');
      }
    }
  });

  $zopim(function() {
    var chatting = $zopim.livechat.isChatting();
    if (chatting)
      $(".zopim").show();

    $zopim.livechat.theme.setColor('#1b75bb');
    $zopim.livechat.theme.reload(); // apply new theme settings
  });

  $(".chat-notification").click(function() {
    $zopim(function() {
      $(".zopim").show();
      $zopim.livechat.window.show();
    });
  })

});
</script>
<style media="screen">
body {
  overflow-x:hidden;
}
/*Navigation*/
#logo {
padding-left: 5%;
}
#logo img {
width: 60%;
}

.navigation_bar--sticky {
background-color: #efefef;
height: 100px;
width: 100%;
position: fixed;
margin-top: 40px;
display: flex;
justify-content: space-around;
align-items: center;
position:fixed;
z-index:55;
}

.navigation_bar--sticky .navigation--sticky {
display: flex;
width: 35%;
justify-content: space-evenly;
font-family: oswald;
font-size: 18px;
list-style: none;
color: #000;
text-transform: uppercase;
}
.navigation_bar--sticky .navigation--sticky a {
color: #000;
text-decoration: none;
padding-left: 40px;
font-weight:500;
}
.navigation_bar--sticky .navigation--sticky a:hover {
text-decoration:underline;
}
.navigation--sticky i {
margin-right:5px;
}
.affirm-top-banner {
width:100%;
height:40px;
z-index:55;
position:absolute;
top:0;
background-color:black;
color:#fff;
display:flex;
justify-content: center;
align-items:center;
font-family: roboto condensed;
text-transform:uppercase;
}
.navigation li {
  display:flex;
  align-items:center;
  height:35px;
  background-repeat:no-repeat;
  background-position:left;
}
#tire-link{
  background-image:url('images/tire-icon-smallv2.png');
}
#tire-link-mobile {
  background-position: 62%;
  background-image:url('images/tire-icon-small-blue.png');
}
#wheel-link {
  background-image:url('images/wheel-icon-3.png');
}
#wheel-link-mobile {
  background-position: 67%;
  background-image:url('images/wheel-icon-blue.png');
  background-size:20%;
}
#packages-link {
  background-image:url('images/wheel-tire-package.png');
}
#packages-link-mobile {
  background-position: 74%;
  background-image:url('images/wheel-tire-package-blue.png');
  background-size:17%;
}
#contact-link {
  background-image:url('images/icons/nav-black-phone-v2.png')
}
#contact-link-mobile {
  background-position: 72%;
  background-image:url('images/icons/nav-blue-phone.png');
  background-size:20%;
}
.hamburger {
  display:none;
}
.hamburger .line{
  width: 50px;
  height: 5px;
  background-color: #1b75bb;
  display: block;
  margin: 8px auto;
  -webkit-transition: all 0.3s ease-in-out;
  -o-transition: all 0.3s ease-in-out;
  transition: all 0.3s ease-in-out;
}

.hamburger:hover{
  cursor: pointer;
}
#hamburger-9{
  position: relative;
  -webkit-transition: all 0.3s ease-in-out;
  -o-transition: all 0.3s ease-in-out;
  transition: all 0.3s ease-in-out;
}

#hamburger-9.is-active{
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  -o-transform: rotate(45deg);
  transform: rotate(45deg);
}

#hamburger-9:before{
  content: "";
  position: absolute;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  width: 70px;
  height: 70px;
  border: 5px solid transparent;
  top: calc(50% - 35px);
  left: calc(50% - 35px);
  border-radius: 100%;
  -webkit-transition: all 0.3s ease-in-out;
  -o-transition: all 0.3s ease-in-out;
  transition: all 0.3s ease-in-out;
}

#hamburger-9.is-active:before{
  border: 5px solid #1b75bb;
}

#hamburger-9.is-active .line{
  width: 35px;
}

#hamburger-9.is-active .line:nth-child(2){
  opacity: 0;
}

#hamburger-9.is-active .line:nth-child(1){
  -webkit-transform: translateY(13px);
  -ms-transform: translateY(13px);
  -o-transform: translateY(13px);
  transform: translateY(13px);
}

#hamburger-9.is-active .line:nth-child(3){
  -webkit-transform: translateY(-13px) rotate(90deg);
  -ms-transform: translateY(-13px) rotate(90deg);
  -o-transform: translateY(-13px) rotate(90deg);
  transform: translateY(-13px) rotate(90deg);
}
#mobile-navigation {
    position: absolute;
    top: 100px;
    background: #efefef;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    padding-bottom: 20px;
    padding-right: 65px;
}
#mobile-navigation li {
    font-size: 24px;
    text-transform: uppercase;
    font-weight: 900;
    color: #1b75bb;
    margin-bottom: 10px;
    font-family: oswald;
    padding-right:78px;
    background-repeat:no-repeat;
}
/*Hero Section*/
.home-hero {
  position: relative;
  overflow: hidden;
  background-image: url(https://cdn.shopify.com/s/files/1/1491/4764/t/3/assets/bg_hero.jpg);
  background-size: cover;
  height: 100vh;
  min-height: 500px;
  max-height: 1000px;
  width: 100%;
}

.bottle-1 {
  position: absolute;
  top: 25%;
  left: calc(39% - 580px);
  z-index: 10;
}

.home-hero-logo {
  z-index: 8;
  position: absolute;
  top: 0;
  bottom: 0;
  right: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}

.bottle-2 {
  position: absolute;
  top: -25%;
  left: 35%;
  z-index: 6;
}

.bottle-3 {
  position: absolute;
  top: 5%;
  right: 10%;
  z-index: 4;
}

.filter h2 {
  font-family: oswald;
  color: #fff;
  text-align: center;
  text-transform: uppercase;
  font-weight: 900;
  font-size: 32px;
  margin-top: 0;
  z-index: 3;
}

h2 {
  font-family: oswald;
  color: #fff;
  text-align: center;
  text-transform: uppercase;
  font-weight: 900;
  font-size: 32px;
  margin-top: 0;
}

/*Filters Section*/
#search_filters {
  background-image: url('images/tire.jpg');
  background-repeat: no-repeat;
  background-position: center;
  background-size:cover;
  width: 100%;
  height: 1080px;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
}

.filter {
  background-color: rgba(0, 0, 0, 0.95);
  width: 20%;
  height: 400px;
  padding: 20px 20px 0 20px;
  box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);
}

.filter_wheels, .filter_tires {
  display: flex;
  flex-direction: column;
  align-items: center;
  overflow: hidden;
}

.filter_wheels {
  background-image: url('https://trello-attachments.s3.amazonaws.com/5bd5353da03a0729178427fb/5c53332b2f81ed1225eab218/982e1fd08d8839eddabd293966530024/glass-container-bg.png');
  background-size: 150%;
  background-position: 50% 55%;
  background-repeat: no-repeat;
}

.filter_wheels .png_container {
  background-image: url('https://trello-attachments.s3.amazonaws.com/5bd5353da03a0729178427fb/5c53332b2f81ed1225eab218/02cd35699064eb2a97071032fcb13b68/glass-shards-vertical.png');
  background-size: contain;
  min-height: 250px;
  width: 100%;
  z-index: 1;
}

.filter_wheels img {
  width: 60%;
  margin-bottom: 5%;
}

.filter_tires img {
  position: relative;
  margin-top:5%;
  z-index:2;

}
#filter-tire {
  animation-iteration-count: 5;
}
.filter_tires .png_container {
  background-image: url('../images/dirt.png');
  min-height: 300px;
  width: 100%;
  z-index: 1;
  position:absolute;
  bottom:0;
}

.png_container {
  display: flex;
  justify-content: center;
  width: 110%;
  position: relative;
  overflow: hidden;
}

form {
  display: flex;
  flex-direction: column;
  z-index:4;
  width:100%;
  margin-top:10px;
}

select {
  margin-bottom: 14px;
  height: 40px;
  font-family: roboto condensed;
  font-size: 15px;
  color:#000;
  padding-left: 10px;
  letter-spacing: 1px;
}

form p {
  color: #fff;
  text-align: center;
  text-transform: uppercase;
  font-weight: 800;
  font-family: roboto condensed;
  font-size: 12px;
  /*   margin-top:40px; */
}

option {
  font-family: roboto condensed;
}

.shards {
  position: absolute;
  width: 100%;
  margin-top: 15%;
}

.shards img {
  width: 100%;
  margin-top: 0;
}

/*Callouts Section*/

/*Callout--CNC*/
.texture {
  background-image:url(images/tire-tread-texture-v3.png);
  background-position:left;
  background-size:cover;
  height:70%;
  width:100%;
  position:absolute;
  z-index:-1;
  opacity:0.3;
}
.content_callouts--cnc .shape {
  width: 100%;
  height: inherit;
  background: rgb(159,159,159);
  background: radial-gradient(circle, rgba(159,159,159,1) 0%, rgba(110,110,110,1) 35%, rgba(64,64,64,1) 100%);
  float: left;
  shape-outside: polygon(0 0, 35% 0%, 50% 100%, 0% 100%);
  clip-path: polygon(0 0, 35% 0%, 50% 100%, 0% 100%);
  -webkit-clip-path: polygon(0 0, 35% 0%, 50% 100%, 0% 100%);
  shape-margin: 10px;
  display:flex;
  justify-content: flex-start;
  align-items:center;
}
.content_callouts--cnc {
	background-image: url('images/cnc-background.jpg');
	background-size: cover;
	background-repeat: no-repeat;
	background-position: bottom;
	background-attachment: fixed;
  height:625px;
}
.callout--cnc {
	width: 40%;
	text-align: left;
	justify-content: center;
	display: flex;
	flex-direction: column;
}
/*Callout--inStock*/
.content_callouts--inStock .shape {
	float: right;
	shape-outside: polygon(50% 0, 100% 0, 100% 100%, 60% 100%);
	clip-path: polygon(50% 0, 100% 0, 100% 100%, 60% 100%);
  -webkit-clip-path: polygon(50% 0, 100% 0, 100% 100%, 60% 100%);
	width: 100%;
	height: inherit;
  background: rgb(159,159,159);
  background: radial-gradient(circle, rgba(159,159,159,1) 0%, rgba(110,110,110,1) 35%, rgba(64,64,64,1) 100%);
  display:flex;
  justify-content: flex-end;
  align-items:center;
}
.content_callouts--inStock {
	background-image: url('images/smoky-tire-v2.jpg');
	background-position: left;
  background-size: 75%;
	background-repeat: no-repeat;
	background-attachment: fixed;
  height:625px;
}
.callout--inStock {
	width: 40%;
	text-align: right;
	margin-left: 57%;
	justify-content: center;
	display: flex;
	flex-direction: column;
  padding-left:10px!important;
}

/*Callout Packages*/
.content_callouts--package .shape {
	width: 100%;
	height: inherit;
  background: rgb(159,159,159);
  background: radial-gradient(circle, rgba(159,159,159,1) 0%, rgba(110,110,110,1) 35%, rgba(64,64,64,1) 100%);
	shape-outside: polygon(0 0, 60% 0%, 50% 100%, 0% 100%);
	clip-path: polygon(0 0, 60% 0%, 50% 100%, 0% 100%);
  -webkit-clip-path: polygon(0 0, 60% 0%, 50% 100%, 0% 100%);
	shape-margin: 10px;
  margin-top:-124px;
  display:flex;
  justify-content: flex-start;
  align-items:center;
}
.content_callouts--package {
	background-image: url('images/wheel-balancing-background.jpg');
	background-repeat: no-repeat;
	background-position: right;
	background-attachment: fixed;
	background-size: contain;
  height:625px;
  margin-top:124px;
}
.callout--package {
	width: 40%;
	text-align: left;
	justify-content: center;
	display: flex;
	flex-direction: column;
}
.feature_buttons {
	justify-content: flex-end;
}
.feature_buttons {
	margin-top: 28px;
	display: flex;
}
.feature_buttons--inStock {
  justify-content:flex-end;
}
.feature_buttons--package {
  justify-content:flex-start;
}
.feature_button {
	background: #345b7f;
	border-radius: 5px;
	font-family: 'oswald';
	padding: 8px 20px;
	font-size: 20px;
	color: #fff;
	margin-top: 20px;
	width: 35%;
	text-align: center;
	text-transform: uppercase;
  text-decoration:none;
  box-shadow:1px 1px 2px black;
}
.feature_button_left {
	margin-right: 15px;
}
.callout-title {
    font-size: 45px;
    line-height: 48px;
    margin-bottom: 25px;
    font-family: 'oswald';
    color: #fff;
    text-shadow: 2px 2px 4px black;
    text-transform: uppercase;
    font-weight: 500;
}
.callout-text {
    font-size: 20px;
    line-height: 36px;
    font-weight: 300;
    letter-spacing: 3px;
    font-family: 'roboto condensed';
    color: #fff;
    /* text-shadow: 2px 2px 4px black; */
}
.callout {
  padding:40px;
}
/*Sub Pages*/
.wheel-results-page, .wheels-page, .tire-results-page, .tires-page, .packages-page {
  background: url(/images/tire-tread-texture-v3.png);
  background-position: center;
  background-size: cover;
  background-attachment: fixed;
  background-repeat: no-repeat;
  background-color: #fff;
}
.wheel-results-page #main, .wheels-page #main, .tire-results-page #main, .tires-page #main, .packages-page #main {
    padding: 140px 0 30px;
}
#advanced-search.container {
  top:190px;
  background-image:none;
  border:none;
  height: auto;
}
#advanced-search-title {
  display:none;
}
.fit-disclaimer {
  font-weight:900;
  font-family:oswald;
}
.results-page-links {
  font-weight:900;
  margin-left: 8.5px;
  color:#000;
  font-family:oswald;
}
.feature-box {
  box-shadow:1px 1px 2px rgba(0,0,0,0.8);
}

/*Media Queries*/
@media only screen and (max-width:1750px) {
  .filter_wheels img {
    width:70%;
    margin-bottom:4%;
  }
  .filter_wheels {
    background-position:50% 101%;
  }
}
@media only screen and (max-width:1500px) {
  .filter_wheels img {
    width: 75%;
    margin-bottom:8%;
  }
  /* .filter_wheels {
    background-position: 50% 101%;
  } */
  .callout--cnc {
    width:35%;
  }
  .texture {
    height:83%;
  }
}
@media only screen and (max-width:1350px;) {
  #search_filters {
    justify-content: space-evenly;
  }
  .clear {
    display:none;
  }
}
@media only screen and (max-width:1275px;) {
  .content_callouts--inStock {
    background-size:85%;
  }
}
@media only screen and (max-width:1200px) {
  .navigation_bar--sticky .navigation--sticky{
    width: 40%;
  }
  #logo {
    width:35%;
  }
}
@media only screen and (max-width:1125px) {
  .content_callouts--inStock {
    background-size:95%;
  }
}
@media only screen and (max-width:1100px) {
  .navigation_bar--sticky .navigation--sticky{
    width: 45%;
  }
  .filter {
    width:23%;
  }
  .filter_tires img {
    height:49%;
    margin-top:34%;
  }
  .hero-search select {
    margin-bottom:0;
    z-index:3;
  }
}
@media only screen and (max-width:1050px) {
  .content_callouts--inStock, .content_callouts--package {
    background-size:100%;
  }
}
@media only screen and (max-width:1000px) {
  .content_callouts--inStock, .content_callouts--package {
    background-size:cover;
  }
}
@media only screen and (max-width:950px) {
  .navigation_bar--sticky{
    justify-content:center;
  }
  .navigation_bar--sticky .navigation--sticky{
    width: 50%;
  }
  .feature_buttons {
    flex-direction:column;
    align-items:flex-end;
  }
  .feature_buttons--package {
    align-items:flex-start;
  }
  .feature_button {
    width:70%;
  }
  .feature_button_left {
    margin-right:0;
  }


}
@media only screen and (max-width:900px) {
  .hero-search#hero-box-wheels {
    margin:0;
  }
  .filter {
    width:35%;
  }
  .filter_vehicle {
    margin-right:2.5%;
  }
  .filter_wheels {
    margin-left:2.5%!important;
  }
  .filter_tires {
    margin-top:-150px;
  }
  #search_filters {
    padding: 200px 0px 70px 0px;
  }
  .filter_tires img {
    height:63%;
    margin-top:12%;
  }
  .content_callouts--inStock {
    background-image:url(images/smoky-tire-v3.jpg);
  }
  .content_callouts--package {
    background-image:url(images/wheel-balancing-background-v3.jpg);
  }

}
@media only screen and (max-width:850px) {
  .navigation_bar--sticky .navigation--sticky{
    display:none;
  }
  .navigation_bar--sticky .hamburger{
    display:block;
  }
  .navigation_bar--sticky {
    justify-content: space-evenly;
  }
  #logo {
    width:50%;
  }
  .callout-title {
    width:85%;
  }
  .callout--package .callout-title {
    width:100%;
  }
}
@media only screen and (max-width:800px) {
  .filter_tires, .filter_wheels {
    display:block!important;
  }
  .callout-title {
    font-size:40px;
  }
  .callout-text {
    font-size:18px;
  }
}
@media only screen and (max-width:750px) {
  #logo img {
    width:70%;
  }
  .callout {
    padding:20px;
  }
}
@media only screen and (max-width:650px) {
  #logo img {
    width:80%;
  }
  #search_filters {
    flex-direction:column;
    justify-content: space-evenly;
    padding: 200px 0px 50px 0px;
  }
  .filter {
    width:50%;
    height:300px;
  }
  .filter_tires {
    margin-top:0;
  }
  .filter_vehicle, .filter_wheels {
    margin:0!important;
  }
  .filter_wheels img {
    width:45%;
    margin-bottom:6%;
  }
  .filter_tires .png_container {
    background-position:50% 275%;
  }
  .filter_tires img {
    margin-top:3%;
    margin-left:22%;
  }
  .content_callouts--cnc .shape {
    shape-outside: polygon(0 0, 50% 0%, 55% 100%, 0% 100%);
    clip-path: polygon(0 0, 50% 0%, 55% 100%, 0% 100%);
    -webkit-clip-path: polygon(0 0, 50% 0%, 55% 100%, 0% 100%);
  }
  .content_callouts--inStock {
      background-image:url('images/smoky-tire-v4.jpg');
  }
  .content_callouts--inStock .shape {
    shape-outside: polygon(55% 0, 100% 0, 100% 100%, 35% 100%);
    clip-path: polygon(55% 0, 100% 0, 100% 100%, 35% 100%);
    -webkit-clip-path: polygon(55% 0, 100% 0, 100% 100%, 35% 100%);
  }
  .hamburger .line {
    width:30px;
    height:3px;
    margin:5px auto;
  }
  #hamburger-9.is-active .line:nth-child(3){
    transform: translateY(-8px) rotate(90deg);
  }
  #hamburger-9.is-active .line:nth-child(1){
    transform: translateY(9px);
  }
  .callout {
    padding:40px;
  }
}
@media only screen and (max-width:600px;) {
  .callout-title {
    font-size:33px;
    width:100%;
  }
}
@media only screen and (max-width:550px) {
  .filter {
    width:60%;
  }
  .callout-title {
    font-size:33px;
    width:100%;
  }
  .feature_buttons {
    margin-top:0px;
  }
}
@media only screen and (max-width:500px) {
  #logo img {
    width:90%;
  }
  .callout--inStock {
    padding-right:20px;
  }
  .callout-title {
    font-size:28px;
  }
}
@media only screen and (max-width:460px) {
  #search_filters {
    background-image:url(images/tire-mobile.jpg);
  }
  .filter {
    width:70%;
  }
  .content_callouts--cnc, .content_callouts--inStock, .content_callouts--package {
    background-image:none;
  }
  .content_callouts--inStock .shape {
    background: rgb(96,96,96);
    background: radial-gradient(circle, rgba(96,96,96,1) 0%, rgba(0,0,0,1) 100%);
  }
  .content_callouts--cnc .shape{
    shape-outside: polygon(0 0, 100% 0%, 100% 100%, 0% 100%);
    clip-path: polygon(0 0, 100% 0%, 100% 100%, 0% 100%);
    -webkit-clip-path: polygon(0 0, 100% 0%, 100% 100%, 0% 100%);
  }
  .content_callouts--inStock .shape {
    shape-outside: polygon(0 0, 100% 0, 100% 100%, 0 100%);
    clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);
    -webkit-clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);
  }
  .content_callouts--package .shape {
    shape-outside: polygon(0 0, 100% 0%, 100% 100%, 0% 100%);
    clip-path: polygon(0 0, 100% 0%, 100% 100%, 0% 100%);
    -webkit-clip-path: polygon(0 0, 100% 0%, 100% 100%, 0% 100%);
  }
  .callout {
    width: 100%;
    text-align:center;
  }
  .callout-title {
    font-size:38px;
    line-height:48px;
  }
  .callout-text {
    font-size:24px;
  }
  .callout--inStock {
    margin-left:0;
  }
  .feature_buttons, .feature_buttons--package {
    align-items:center;
  }
}
@media only screen and (max-width:395px) {
  .filter {
    width: 80%;
  }
  .filter_tires img {
    margin-left: 20%;
  }
  .callout {
    padding:20px;
  }
}
</style>
<link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700|Roboto+Condensed:300,300i,400,400i,700,700i" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

</head>
<body class="<?=$PageClass;?>">
    <div class="affirm-top-banner">
        <p>Prequalify for <span style="color:#0fa0ea;">AFFIRM</span> Financing. Apply Now!</p>
      </div>
      <div class="navigation_bar--sticky">
        <div id="logo"><a href="/"><img src="images/logo-main-long.png" alt="tires and wheels logo"></a></div>
        <ul class="navigation navigation--sticky" id="navigation">
          <li id="tire-link"><a href="/tires.php">Tires</a></li>
          <li id="wheel-link"><a href="/wheels.php">Wheels</a></li>
          <li id="packages-link"><a href="/packages.php">Packages</a></li>
          <li id="contact-link"><a href="/contact.php">Contact</a></li>
          <?php
              if ($CartCount != 0) {
                echo "
                <li class='menu-item'>
                  <a href='/cart.php' class='mobile-cart-link'>My Cart<span id='cart-icon-sm' class='sprite'><span id='cart-count-sm'>".$CartCount."</span></span></a>
                </li>";
              }
              ?>
        </ul>
        <div class="hamburger" id="hamburger-9">
         <span class="line"></span>
         <span class="line"></span>
         <span class="line"></span>
       </div>
       <ul id="mobile-navigation" style="display:none;">
         <li id="tire-link-mobile"><a href="/tires.php">Tires</a></li>
         <li id="wheel-link-mobile"><a href="/wheels.php">Wheels</a></li>
         <li id="packages-link-mobile"><a href="/packages.php">Packages</a></li>
         <li id="contact-link-mobile"><a href="/contact.php">Contact</a></li>
         <?php
             if ($CartCount != 0) {
               echo "
               <li class='menu-item'>
                 <a href='/cart.php' class='mobile-cart-link'>My Cart<span id='cart-icon-sm' class='sprite'><span id='cart-count-sm'>".$CartCount."</span></span></a>
               </li>";
             }
             ?>
       </ul>
      </div>
      <div id="full-screen-loader">
        <div id="table-fix">
          <div class="ecl-wrap">
            <div class="rel-wrap">
              <img src="/images/ec-logo-circle.png" id="loading-circle" alt="App Guide Loading Animation" />
              <img src="/images/ec-logo-center.png" id="loading-center" alt="App Guide Loading"/>
            </div>
          </div>
        </div>
      </div>

<?php
if ($Page != 'home') : ?>
<!-- <div class="container" id="interior-hero">
  <div class="dot-overlay"></div>
  <div class="row">
    <div class="twelve">
      <h1><?=$HeroTitle;?></h1>
    </div>
    <div class="clear"></div>
  </div>
</div> -->
<?php endif; ?>
