<?php
$PageMetaTitle = 'Wheels at TiresAndWheels.com';
$PageMetaDesc = 'TiresAndWheels.com stocks Fuel Off Road, XD Series, ATX Series, Deegan 38, Diamo, Dick Cepek, Ballistic, Cruiser Alloy, Gear Alloy, Helo, Ultra, Worx, Monster Energy Wheels, TIS, Dropstars, DUB, Niche, ION  Alloy, Motiv, Foose, Vision, Walker Evans and many more! Tires And Wheels, Tire Reps and Extreme Customs, teaming up to save you money!';
$PageMetaKeyW = 'tires and wheels,extreme customs,tire reps,wheel and tire packages,fuel off road,xd series,atx series,Deegan 38,vision,monster energy wheels,tis,dropstars,dub,niche,foose,ultra,worx';
$Page = 'wheels';
$PageClass = 'wheels-page';
$HeroTitle = 'Wheels';
include ('includes/header.php');

if ( GetCurVid() ) {
  echo"
  <script>
    window.location.href = '/wheel-results.php'
  </script>";
}

$appguide_action = 'wheel-results.php';
include ('includes/app-guide.php');
?>

<div class="container inner-content" id="main">
  <div class="row">
    <div class="twelve">

      <div class="featured-title">Shop For Wheels By:</div>

      <div class="clear"></div>

      <div class="wheel-search-selection">
        <h3>Vehicle</h3>
        <a href="#" data-role="target-app-guide" class="highlight-app-guide button">Select Year Above</a>   
      </div>

      <div id="bp-select-box" class="wheel-search-selection">
        <h3>Bolt Pattern</h3>
      <?php 
        $storeid = 4;
        $width = 0;
        $bolt 	= $_GET['bc'];

        $BoltArray 	= WheelUniqueBoltArray ( $storeid );

        echo "
        <form name=search action='wheel-results.php'>
        
          <select name='bc' OnChange=submit()>
            <option value=''>Choose a Bolt Pattern</option>";
            if ( is_array( $BoltArray ) ) :
              foreach($BoltArray as $val ){
                echo " 
                <option value='$val'".ilif($val,$_GET['bc']," SELECTED",'').">$val</option>";
              }
            endif;
          echo "
          </select>
        </form>";

        $RESULT	= WheelResultArrayMax ($storeid,$bolt,$minsize,$maxsize,$minwidth,$maxwidth,$minoffset,$maxoffset,$minhub,$maxhub,$minload,$maxload,$finish,$construction,$brand,$invlimitone,$featurelimit,$perpage,$curpage,$sort);
      ?>
      </div>

      <div class="wheel-search-selection">
        <h3>Brand</h3>
        <a href="brands.php?btype=10" class="button">Shop by brand</a>
      </div>

    </div>
    <div class="clear"></div>
  </div>
</div>

<?php
include ('includes/footer.php'); ?>