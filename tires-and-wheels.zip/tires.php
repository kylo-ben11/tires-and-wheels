<?php
$PageMetaTitle = 'Tires at TiresAndWheels.com';
$PageMetaDesc = 'TiresAndWheels.com stocks Nitto, Toyo, Hankook, BFGoodrich, Michelin, Atturo, Federal, Fuel, Falken, Kumho, Nexen, Mickey Thompson, Dick Cepek, Bridgestone, Continental, Dunlop, Firestone, Goodyear, Kelly, Pirelli and many more! Tires And Wheels, Tire Reps and Extreme Customs, teaming up to save you money!';
$PageMetaKeyW = 'tires and wheels,extreme customs,tire reps,wheel and tire packages,nitto,toyo,nankook,bfgoodrich,bfg,michelin,atturo,federal,fuel,falken,kumho,nexen,mickey thompson,dick cepek, bridgestone,continental,dunlop,firestone,goodyear,kelly,Pirelli';
$Page = 'tires';
$PageClass = 'tires-page';
$HeroTitle = 'Tires';
include ('includes/header.php');
include ('includes/app-guide.php');
?>

<div class="container" id="main">
  <div class="row">
    <div class="twelve">
        
      <div class="featured-title">What's Your Wheel Size?</div>
      
      <div class="clear"></div>

      <?php 
      $storeid = 4;
      $width = 0;
      $dim = $_GET['mntsize'];

      $DimArray = TireDIMUniqueArrayMax ($storeid,$width,$minod,$maxod,$mincs,$maxcs,$minas,$maxas,$serv,$speed,$rating,$load,$brand,$sw,$invlimitone,$featurelimit);

      echo "
      <form name=search action='tire-results.php'>
      
        <select name='mntsize' OnChange=submit()>
          <option value=''>Choose a Size</option>";
          if ( is_array( $DimArray ) ) :
            foreach($DimArray as $val ){
              echo " 
              <option value='$val'".ilif($val,$_GET['mntsize']," SELECTED",'').">$val</option>";
            }
          endif;
        echo "
        </select>
      </form>";

      $RESULT = StockWheelToVechMaxArray (4,GetCurVid ( ),$_GET['finish'],$_GET['construction'],$_GET['brand'],$_GET['minrim'],$_GET['maxrim'],$_GET['minwidth'],$_GET['maxwidth'],$_GET['minoffset'],$_GET['maxoffset'],$perpage,$_GET['s-page'],$_GET['sort'],$stklimit,$featured ) ;
      ?>
      
      <p class='select-wheel-size'>Please enter your wheel size (last number when looking at your tires).<br> If your unsure of what it is, please call 888-258-4737 and we'll help you out!</p>
      
      <div class="tire-search-brands">
        <a href="brands.php?btype=20" class="button">Or Shop by brand</a>
      </div>

    </div>
    <div class="clear"></div>
  </div>
</div>

<?php
include ('includes/footer.php'); ?>