<?php
	// -- Include Syslink WP API Using your current db
	include_once ( 'inc.store/ssc.wp.api.php' ) ;

// The idea here is to end up with the vid (vech id) 
// this is Set and Stored with the SetCurVid ( $vid ) function
// Then it can be accessed later with the GetCurVid ( ) function

// set the VID if needed
	if ( is_numeric ( $_GET['vid'] ) ) {
	 SetCurVid ( $_GET['vid'] ) ;
	}	// ( is_numeric ( $_GET['vid'] ) )

// start the search form
echo "
<form name=search>";

// if there is a vid set we dont display the drop downs
	if ( IsValidVID ( GetCurVid ( ) ) ) {

// we show the vid info and offer a reset
echo "
<b>".GetModelYear ( GetCurVid ( ) )." ".GetModelMake ( GetCurVid ( ) )." ".GetModelName ( GetCurVid ( ) )." ".GetModelSub ( GetCurVid ( ) )." </b><a href='ex_appguide.php?vid=0'>(Reset)</a><br>";
	} else {	// - ( IsValidVID ( GetCurVid ( ) ) )
// No Vid Set Yet so Lets display the drop downs
// First we gather the array info and build the arrays
	$yeararry 	= GetYearArray ( );
	$makearray 	= GetMakeArray ( $_GET['year'] );
	$modelarray = GetModelArray ( $_GET['year'], $_GET['make'] );
	$submarray 	= GetSubModelArray ( $_GET['year'], $_GET['make'], $_GET['model'] );

// Then we build each of the drop downs with the array info
echo "
<select name=year OnChange='submit()'>
 <option value=''>Please Select</option>";
if(is_array($yeararry)){
 foreach($yeararry as $year) {
echo "
 <option value='".$year."'".ilif($_GET['year'],$year," SELECTED",'').">".$year."</option>";
 }
}
echo "
</select>";
echo "
<select name=make OnChange='submit()'>
 <option value=''>Please Select</option>";
if(is_array($makearray)){
 foreach($makearray as $makeid=>$make) {
echo "
 <option value='".$makeid."'".ilif($_GET['make'],$makeid," SELECTED",'').">".$make."</option>";
 }
}
echo "
</select>";
echo "
<select name=model OnChange='submit()'>
 <option value=''>Please Select</option>";
if(is_array($modelarray)){
 foreach($modelarray as $model) {
echo "
 <option value='".$model."'".ilif($_GET['model'],$model," SELECTED",'').">".$model."</option>";
 }
}
echo "
</select>";
echo "
<select name=vid OnChange='submit()'>
 <option value=''>Please Select</option>";
if(is_array($submarray)){
 foreach($submarray as $modelid=>$submod) {
echo "
 <option value='".$modelid."'".ilif(GetCurVid ( ),$modelid," SELECTED",'').">".$submod."</option>";
 }
}
echo "
</select><br>";

	}	// - end- else - ( IsValidVID ( GetCurVid ( ) ) )

// we again check if the vid is set so we know if we should 
// display the results or not also we can decide what to display too
if( IsValidVID ( GetCurVid ( ) ) ){

// Ok so a VID is set so what now?
// by deault i will just display the wheel results
// with some extra wheel sorting
// but you can besicly do anyting at this point ..

// load the other sorting arrays and check for the results
$FinishArray 	= MaxWheelUniqueFinishArrayVech ($storeid,GetCurVid ( ),$_GET['construction'],$_GET['brand'],$_GET['size'],$_GET['width'],$_GET['offset']);
$TypeArray    = MaxWheelUniqueTypeArrayVech ($storeid,GetCurVid ( ),$_GET['finish'],$_GET['brand'],$_GET['size'],$_GET['width'],$_GET['offset']);
$BrandArray 	= MaxWheelUniqueBrandArrayVech ($storeid,GetCurVid ( ),$_GET['finish'],$_GET['construction'],$_GET['size'],$_GET['width'],$_GET['offset']);
$SizeArray 	  = MaxWheelUniqueSizeArrayVech ($storeid,GetCurVid ( ),$_GET['finish'],$_GET['construction'],$_GET['brand'],$_GET['width'],$_GET['offset']);
$WidthArray 	= MaxWheelUniqueWidthArrayVech ($storeid,GetCurVid ( ),$_GET['finish'],$_GET['construction'],$_GET['brand'],$_GET['size'],$_GET['offset']);
$OffSetArray 	= MaxWheelUniqueOffsetArrayVech ($storeid,GetCurVid ( ),$_GET['finish'],$_GET['construction'],$_GET['brand'],$_GET['size'],$_GET['width']);

echo "
<select name='finish' OnChange=document.search.submit()>
 <option value=''>Please Select</option>";
 if ( is_array($FinishArray) ) {
  foreach( $FinishArray as $Finish  ) {

echo "
 <option value='$Finish'".ilif($_GET['finish'],$Finish," SELECTED",'').">$Finish</option>";
  }	// - ( $FinishArray as $Finish  )
 }	// - ( is_array($FinishArray) )
echo "
</select>Finish<br>

<select name='construction' OnChange=document.search.submit()>
 <option value=''>Please Select</option>";
 if ( is_array($TypeArray) ) {
  foreach( $TypeArray as $Type  ) {

echo "
 <option value='$Type'".ilif($_GET['construction'],$Type," SELECTED",'').">$Type</option>";

  }	// - ( $TypeArray as $Type  )
 }	// - ( is_array($TypeArray)
echo "
</select>Construction<br>

<select name='brand' OnChange=document.search.submit()>
 <option value=''>Please Select</option>";
if ( is_array($BrandArray) ) {
 foreach( $BrandArray as $Brand  ) {

echo "
 <option value='$Brand'".ilif($_GET['brand'],$Brand," SELECTED",'').">$Brand</option>";

  }	// - ( $BrandArray as $Brand  ) 
 }	// - ( is_array($BrandArray) )
echo "
</select>Brand<br>
<select name='size' OnChange=document.search.submit()>
 <option value=''>Please Select</option>";
if ( is_array($SizeArray) ) {
 foreach( $SizeArray as $Size  ) {

echo "
 <option value='$Size'".ilif($_GET['size'],$Size," SELECTED",'').">$Size</option>";

  }	// - ( $SizeArray as $Size  ) 
 }	// - ( is_array($SizeArray) )
echo "</select>Wheel Size<br>
<select name='width' OnChange=document.search.submit()>
 <option value=''>Please Select</option>";
if ( is_array($WidthArray) ) {
 foreach( $WidthArray as $Width  ) {

echo "
 <option value='$Width'".ilif($_GET['width'],$Width," SELECTED",'').">$Width</option>";

  }	// - ( $WidthArray as $Width  ) 
 }	// - ( is_array($WidthArray) )
echo "</select>Wheel Width<br>
<select name='offset' OnChange=document.search.submit()>
 <option value=''>Please Select</option>";
if ( is_array($OffSetArray) ) {
 foreach( $OffSetArray as $Offset  ) {

echo "
 <option value='$Offset'".ilif($_GET['offset'],$Offset," SELECTED",'').">$Offset</option>";

  }	// - ( $OffSetArray as $Offset  ) 
 }	// - ( is_array($OffSetArray) )

echo "
</select>Wheel Offset<br>
</form>";


// Then I set some of the output information vars
 // items per page of output
	$perpage = 50;
 // What Page To Display
	$curpage = $_GET['page'];
 // Sort The Results Var
	$sort = $_GET['sort'];
 // Load the Wheel RESULT Array

	$RESULT = MaxWheelToVechArray ( $storeid,GetCurVid ( ),$_GET['finish'],$_GET['construction'],$_GET['brand'],$_GET['size'],$_GET['width'],$_GET['offset'],$perpage,$curpage,$sort );

// This info isnt normaly displayed like this but for this example
echo "<br>";
echo "Total Pages : ".$RESULT['TotalPages']." - ";
echo "Results Per Page : ".$RESULT['PerPage']." - ";
echo "Curent Page : ".$RESULT['CurPage']." - ";
echo "Total Count : ".$RESULT['Count']."<br>";


/*
Ok - Lets Check for a result array
then if found lets extract it
*/

 if ( is_array ( $RESULT['ID'] ) ) {
echo "<br>Extract ItemID Result Array<br><br>";
// We can build any kind of result page witht he item ids provided
// I will just extract some basic info for this example

  foreach ( $RESULT['ID'] as $itemid ) {
echo $itemid." - ".GetItemSKU ( $itemid, $storeid )." - $".number_format(GetItemPrice ( $itemid, $storeid  ), 2, '.', '')."<br>";
  }     // - ( $RESULT['ID'] as $itemid )
 }	// - ( is_array ( $RESULT['ID'] ) )
}	// - ( IsValidVID ( GetCurVid ( ) ) )
