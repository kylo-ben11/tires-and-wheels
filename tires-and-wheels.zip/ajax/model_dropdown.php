<?php
	// -- Include Syslink WP API Using your current db
	include_once ( $_SERVER['DOCUMENT_ROOT'] . '/inc.store/ssc.wp.api.php' ) ;
	
	$modelarray 	= GetModelArray ( $_GET['year'], $_GET['make'] );

	echo "<option value=\"\">Model</option>";
	if(is_array($modelarray)) {
    asort($modelarray);
	 	foreach($modelarray as $model) {
			echo "<option value='".$model."'".ilif($_GET['model'],$model," SELECTED",'').">".$model."</option>";
	 	}
	}