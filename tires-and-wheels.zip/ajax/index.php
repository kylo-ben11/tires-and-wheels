<?
	header("Location: ../");