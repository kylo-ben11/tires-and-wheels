<?php
    include_once ( $_SERVER['DOCUMENT_ROOT'] . '/inc.store/ssc.wp.api.php' );

    // Then I set some of the output information vars
    // items per page of output
    $perpage = 75;
    // What Page To Display
    $curpage = $_GET['s-page'];
    // Sort The Results Var
    $sort = intval($_GET['c-sort']);

    if (empty($sort))
      $sort = 1;
    // Load the Wheel RESULT Array
    //$RESULT = WheelResultArrayVech ($storeid,GetCurVid ( ),$_GET['finish'],$_GET['construction'],$_GET['brand'],$perpage,$curpage,$sort);
    
    
    if ($_GET['availability'] == "featured") {
        //$RESULT = GetFeaturedItemArrayPlus ( 'wheel',$storeid,$perpage,$curpage,$sort );
        $RESULT = GetFeaturedWheelArrayVid ( $storeid,GetCurVid(),$perpage,$curpage,$sort);
    } else {
        $RESULT = WheelResultArrayVechWSize ($storeid,GetCurVid ( ),$_GET['finish'],$_GET['construction'],$_GET['brand'],$_GET['size'],$perpage,$curpage,$sort);
    }
?>

<h2><strong>WHEEL</strong> SEARCH RESULTS</h2>
        <?php

            $current_page = 1;

            if (isset($_GET['s-page']))
                $current_page = $_GET['s-page'];

            $total_shown = $perpage;
            if ($total_shown > $RESULT['Count'])
                $total_shown = $RESULT['Count'];
        ?>

        
        <?php if ($total_shown > 0 && !empty($total_shown)) : ?>
        <div id="displaying-results">
            Displaying <?=$total_shown;?> of <?=$RESULT['Count'];?> Results | 
            <?php
                $max_display = 6;
                $displayed = 0;

                if ($current_page > 3) {
                    echo "...";
                }

                for ($i = max(1, $current_page - 3); $i <= $RESULT['TotalPages']; $i++) : ?>
                    <?php
                        $displayed++;
                        if ($displayed >= $max_display) break;
                    ?>
                    <?php if ($i == $current_page) : ?>
                        <a class="current" href="<?=$_SERVER['request_uri'];?>?finish=<?=$_GET['finish'];?>&construction=<?=$_GET['construction'];?>&brand=<?=$_GET['brand'];?>&s-page=<?=$i;?>"><?=$i;?></a>
                    <?php else : ?>
                        <a href="<?=$_SERVER['request_uri'];?>?finish=<?=$_GET['finish'];?>&construction=<?=$_GET['construction'];?>&brand=<?=$_GET['brand'];?>&s-page=<?=$i;?>"><?=$i;?></a> 
                    <?php endif; ?>
                <?php endfor;

                if ($current_page + 4 <= $RESULT['TotalPages']) {
                    echo "...";
                }

                /*
                 Sort values For Wheels :
                  1  - Price Low to High ASC        
                  2  - Price High to Low 
                  3  - Name Low to High ASC     
                  4  - Name High to Low
                  5  - Brand Low to High ASC        
                  6  - Brand High to Low
                  7  - Partnum Low to High ASC      
                  8  - Partnum High to Low
                  9  - UPC ASC
                  10 - Diameter Low to High ASC     
                  11 - Diameter High to Low
                  12 - Width Low to High ASC        
                  13 - Width High to Low
                  14 - OffSet Low to High ASC       
                  15 - OffSet High to Low
                  16 - Hub Size Low to High ASC     
                  17 - Hub Size High to Low
                  18 - Load Rating Low to High ASC  
                  19 - Load Rating High to Low
                  20 - Finish Low to High  ASC      
                  21 - Finish High to Low
                */
            ?>
            <?php if (!isset($_GET['c-sort']) || intval($_GET['c-sort']) == 1) : ?>
                <select name="c-sort" id='csort'>
            <?php else : ?>
                <select name="c-sort" id='csort' class="changed">
            <?php endif; ?>
                <option disabled value="1"<?=ilif($_GET['c-sort'], false,' selected="selected"','');?> style="display: none;">Sort</option>
                <option value="1"<?=ilif($_GET['c-sort'], "1",' selected="selected"','');?> style="color: #333333;">Price: Low to High</option>
                <option value="2"<?=ilif($_GET['c-sort'], "2",' selected="selected"','');?> style="color: #333333;">Price: High to Low</option>
                <option value="3"<?=ilif($_GET['c-sort'], "3",' selected="selected"','');?> style="color: #333333;">Name: A-Z</option>
                <option value="4"<?=ilif($_GET['c-sort'], "4",' selected="selected"','');?> style="color: #333333;">Name: Z-A</option>
                <option value="5"<?=ilif($_GET['c-sort'], "5",' selected="selected"','');?> style="color: #333333;">Brand: A-Z</option>
                <option value="6"<?=ilif($_GET['c-sort'], "6",' selected="selected"','');?> style="color: #333333;">Brand: Z-A</option>
                <option value="7"<?=ilif($_GET['c-sort'], "7",' selected="selected"','');?> style="color: #333333;">Partnum: Low to High</option>
                <option value="8"<?=ilif($_GET['c-sort'], "8",' selected="selected"','');?> style="color: #333333;">Partnum: High to Low</option>
                <option value="9"<?=ilif($_GET['c-sort'], "9",' selected="selected"','');?> style="color: #333333;">UPC: Low to High</option>
                <option value="10"<?=ilif($_GET['c-sort'], "10",' selected="selected"','');?> style="color: #333333;">Diameter: Low to High</option>
                <option value="11"<?=ilif($_GET['c-sort'], "11",' selected="selected"','');?> style="color: #333333;">Diameter: High to Low</option>
                <option value="12"<?=ilif($_GET['c-sort'], "12",' selected="selected"','');?> style="color: #333333;">Width: Low to High</option>
                <option value="13"<?=ilif($_GET['c-sort'], "13",' selected="selected"','');?> style="color: #333333;">Width: High to Low</option>
                <option value="14"<?=ilif($_GET['c-sort'], "14",' selected="selected"','');?> style="color: #333333;">OffSet: Low to High</option>
                <option value="15"<?=ilif($_GET['c-sort'], "15",' selected="selected"','');?> style="color: #333333;">OffSet: High to Low</option>
                <option value="16"<?=ilif($_GET['c-sort'], "16",' selected="selected"','');?> style="color: #333333;">Hub Size: Low to High</option>
                <option value="17"<?=ilif($_GET['c-sort'], "17",' selected="selected"','');?> style="color: #333333;">Hub Size: High to Low</option>
                <option value="18"<?=ilif($_GET['c-sort'], "18",' selected="selected"','');?> style="color: #333333;">Load Rating: Low to High</option>
                <option value="19"<?=ilif($_GET['c-sort'], "19",' selected="selected"','');?> style="color: #333333;">Load Rating: High to Low</option>
                <option value="20"<?=ilif($_GET['c-sort'], "20",' selected="selected"','');?> style="color: #333333;">Finish: Low to High</option>
                <option value="21"<?=ilif($_GET['c-sort'], "21",' selected="selected"','');?> style="color: #333333;">Finish: High to Low</option>
            </select>
        </div>
        <?php endif; ?>

        </form>



    <?php if ($total_shown == 0 || empty($total_shown)) : ?>
        <p>We couldn't find any results for the options you selected. Please try selecting some different options to view results.</p>
    <?php endif; ?>
        <?php


    /*
    Ok - Lets Check for a result array
    then if found lets extract it
    */



    if ( is_array ( $RESULT['ID'] ) ) {
        // We can build any kind of result page witht he item ids provided
        // I will just extract some basic info for this example

        $i = 0;
        foreach ( $RESULT['ID'] as $itemid ) : ?>
            <?php
                $storeid = 4;
                $r = $itemid;

                $name = GetItemName($r, $storeid);
                $brand = GetItemBrand($r, $storeid);
                $price = GetItemPrice($r, $storeid);
                if (GetCustId()) {
                    $price = CheckPriceSmart(GetCustId(), $r);
                }
                $images = ListItemImg ($r);
                $ikey = sizeof($images) - 2;
                $image = GetItemImg($r, $images[$ikey]);

                
                $wheeldiameter = GetWheelKey($r, 'Diameter');
                $wheelwidth = GetWheelKey($r, 'Width');
                $wheeloffset = AddThePlus(GetWheelKey($r, 'OffSet'));
            ?>

            <?php if ($i % 3 == 0) : ?>
                <a href="/product/?p-id=<?=$r;?>" class="first feature-box" style="overflow: visible;">
            <?php else : ?>
                <a href="/product/?p-id=<?=$r;?>" class="feature-box" style="overflow: visible;">
            <?php endif; ?>
                <div class="feature-image" style="background-image: url('/<?=$image;?>'); background-size: contain;"></div>
                <p class="feature-title brand"><?=$brand;?></p>
                <p class="feature-title"><?=$name;?></p>
                <p class="feature-description">
                    Size: <?=str_replace ('.0','',$wheeldiameter);?>x<?=str_replace ('.0','',$wheelwidth);?><br />
                    Offset: <?=$wheeloffset;?>
                </p>
                <?php if (empty($price) || intval($price) == 0) : ?>
                    <p class="feature-price call">Call for Pricing<br />866-680-7467</p>
                <?php else : ?>
                    <p class="feature-price"><?=money_format('$%i', $price);?></p>
                <?php endif; ?>
            </a>
        <?php $i++; endforeach;
    }

?>