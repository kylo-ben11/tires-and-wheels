<?php
	// -- Include Syslink WP API Using your current db
	include_once ( $_SERVER['DOCUMENT_ROOT'] . '/inc.store/ssc.wp.api.php' ) ;

	$makearray 	= GetMakeArray ( $_GET['year'] );

	echo "<option value=\"\">Make</option>";
	if(is_array($makearray)){
    asort($makearray);
	 	foreach($makearray as $makeid=>$make) {
			echo "<option value='".$makeid."'".ilif($_GET['make'],$makeid," SELECTED",'').">".$make."</option>";
	 	}
	}