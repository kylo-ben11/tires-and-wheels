<?php
	// -- Include Syslink WP API Using your current db
	include_once ( $_SERVER['DOCUMENT_ROOT'] . '/inc.store/ssc.wp.api.php' ) ;

	$storeid = 4;
	$year = $_GET['year'];
	$make = $_GET['make'];
	$model = $_GET['model'];
	$vid = $_GET['vid'];
	$product = $_GET['product'];
	$curpage = 1;
	$perpage = 99999;

	if (empty($vid) || $vid == 0) : ?>
		<p><span class="error">You must complete all fields in order to continue.</span></p>
	<?php else : ?>
		<?php
			$result = WheelResultArrayVech ($storeid,$vid,'','','',$perpage,$curpage,1);
			if (in_array(intval($product), $result['ID'])) : ?>
				<p><span class="success">Your vehicle is compatible with this product.</span></p>
				<p class="buttons">
					<a href="#" class="button" id="view-product">Continue</a>
				</p>
			<?php else : ?>
				<p><span class="error">Your vehicle is not compatible with this product. What would you like to do?</span></p>
				<p class="buttons">
					<a href="/search-results/?c-year=<?=$year;?>&c-make=<?=$make;?>&c-model=<?=$model;?>&c-vid=<?=$vid;?>" class="button" id="view-compatible-products">View Compatible Products</a>
					<a href="#" class="button" id="view-product">View Product Anyways</a>
				</p>
				<div class="clear"></div>
			<?php endif;
		?>
	<?php endif; ?>