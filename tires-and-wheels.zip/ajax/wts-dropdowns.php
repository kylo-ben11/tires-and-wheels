<?php
	include_once ( $_SERVER['DOCUMENT_ROOT'] . '/inc.store/ssc.wp.api.php' ) ;
  
  $size = $_GET['size'];
  $finish = $_GET['finish'];
  $brand  = $_GET['brand'];
  $construction = $_GET['construction'];
  $availability = $_GET['availability'];

	$storeid = 4;

  $SizeArray    = MaxWheelUniqueSizeArrayVech ($storeid,GetCurVid ( ),$_GET['finish'],$_GET['construction'],$_GET['brand'],$_GET['width'],$_GET['offset']);
  $FinishArray  = MaxWheelUniqueFinishArrayVech ($storeid,GetCurVid ( ),$_GET['construction'],$_GET['brand'],$_GET['size'],$_GET['width'],$_GET['offset']);
  $TypeArray    = MaxWheelUniqueTypeArrayVech ($storeid,GetCurVid ( ),$_GET['finish'],$_GET['brand'],$_GET['size'],$_GET['width'],$_GET['offset']);
  $BrandArray   = MaxWheelUniqueBrandArrayVech ($storeid,GetCurVid ( ),$_GET['finish'],$_GET['construction'],$_GET['size'],$_GET['width'],$_GET['offset']);
    
    if (!empty($size))
        echo "<select name='size' id='csize' class='changed'>";
    else 
        echo "<select name='size' id='csize'>";
    echo "
        <option value='' disabled style='display:none;'>Select a Size</option>
        <option value='' style='color:#333333;'>All Sizes</option>";
        if ( is_array($SizeArray) ) {
            foreach( $SizeArray as $Size  ) {

                echo "
                    <option value='$Size'".ilif($_GET['size'],$Size," SELECTED",'')." style='color:#333333;'>$Size</option>";
            }
        }
        echo "
    </select>";

    if (!empty($finish))
        echo "<select name='finish' id='cfinish' class='changed'>";
    else 
        echo "<select name='finish' id='cfinish'>";
    echo "
        <option value='' disabled style='display:none;'>Select a Finish</option>
        <option value='' style='color:#333333;'>All Finishes</option>";
        if ( is_array($FinishArray) ) {
            foreach( $FinishArray as $Finish  ) {

                echo "
                    <option value='$Finish'".ilif($_GET['finish'],$Finish," SELECTED",'')." style='color:#333333;'>$Finish</option>";
            }
        }
        echo "
    </select>";

    if (!empty($brand))
        echo "<select name='brand' id='cbrand' class='changed'>";
    else 
        echo "<select name='brand' id='cbrand'>";
    echo "
        <option value='' disabled style='display:none;'>Select a Brand</option>
        <option value='' style='color:#333333;'>All Brands</option>";
        if ( is_array($BrandArray) ) {
            foreach( $BrandArray as $Brand  ) {

                echo "
                    <option value='$Brand'".ilif($_GET['brand'],$Brand," SELECTED",'')." style='color:#333333;'>$Brand</option>";

            }
        }
        echo "
    </select>";

    if (!empty($construction))
        echo "<select name='construction' id='cconstruction' class='changed'>";
    else 
        echo "<select name='construction' id='cconstruction'>";
    echo "
        <option value='' disabled style='display:none;'>Select a Construction</option>
        <option value='' style='color:#333333;'>All Constructions</option>";
        if ( is_array($TypeArray) ) {
            foreach( $TypeArray as $Type  ) {

                echo "
                <option value='$Type'".ilif($_GET['construction'],$Type," SELECTED",'')." style='color:#333333;'>$Type</option>";

            }
        }
        echo "
    </select>";

    if (!empty($availability))
        echo "<select name='availability' id='cavailability' class='changed'>";
    else 
        echo "<select name='availability' id='cavailability'>";
    echo "
        <option value='' disabled style='display:none;'>Availability</option>
        <option value='' style='color:#333333;'>All Availabilities</option>
        <option value='featured'".ilif($_GET['availability'], "featured", " selected", '')." style='color:#333333;'>Featured Items</option>
    </select>";
?>