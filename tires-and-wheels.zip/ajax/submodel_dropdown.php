<?php
	// -- Include Syslink WP API Using your current db
	include_once ( $_SERVER['DOCUMENT_ROOT'] . '/inc.store/ssc.wp.api.php' ) ;

	$submarray 	= GetSubModelArray ( $_GET['year'], $_GET['make'], $_GET['model'] );

	echo "<option value=\"\">Sub Model</option>";
	if(is_array($submarray)){
    asort($submarray);
 		foreach($submarray as $modelid=>$submod) {
			echo "<option value='".$modelid."'".ilif(GetCurVid ( ),$modelid," SELECTED",'').">".$submod."</option>";
 		}
	}