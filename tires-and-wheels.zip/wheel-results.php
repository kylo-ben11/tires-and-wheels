<?php
$PageMetaDesc = 'TiresAndWheels.com stocks Fuel Off Road, XD Series, ATX Series, Deegan 38, Diamo, Dick Cepek, Ballistic, Cruiser Alloy, Gear Alloy, Helo, Ultra, Worx, Monster Energy Wheels, TIS, Dropstars, DUB, Niche, ION  Alloy, Motiv, Foose, Vision, Walker Evans and many more! Tires And Wheels, Tire Reps and Extreme Customs, teaming up to save you money!';
$PageMetaKeyW = 'tires and wheels,extreme customs,tire reps,wheel and tire packages,fuel off road,xd series,atx series,Deegan 38,vision,monster energy wheels,tis,dropstars,dub,niche,foose,ultra,worx';
$Page = 'wheel-results';
$PageClass = 'wheel-results-page';
$HeroTitle = 'Wheel Results';
$AddJs[1] = 'js/result-dropdowns.js';
include ('includes/header.php');

$appguide_reset = 'wheels.php?c-vid=0';
include ('includes/app-guide.php');
?>

<?php
if ( GetCurVid() ) { 
  
  if ( $_GET['PU'] != 1 ) { ?>
    <div id="pageload-popup" class="wheel-search-pu1 container">
  <?php } else { ?>
    <div id="pageload-popup" class="wheel-search-pu2 container">
  <?php } ?>

      <div class="row">
        <div class="modal twelve">
          <h3>Are you going to lift, level or lower your vehicle?</h3>
          <a href="#" id="adv-fitment-button" class="fitment-btn button">Yes</a>
          <a href="#" id="stock-fitment-button" class="fitment-btn button">No</a>
          <a href="#" class="close close-btn sprite"></a>
        </div>
      </div>
      <div class="popup-mask"></div>
    </div>

<?php } ?>

<div class="container" id="main">
  <div class="row">
    <div class="twelve last">    

    <?php
      if ( $_GET['topsellers'] == "Top Sellers") {
        $stklimit = 4;
      }

      if ( $_GET['topsellers'] == "Featured") {
        $featured = 1;
      }

      if ( $_GET['topsellers'] == "QuickShip") {
        $featured = 2;
      }

      if ( $_GET['topsellers'] == "Blowout") {
        $featured = 3;
      }

      $perpage = 36;

      if ( GetCurVid() ) :
        
        if ( strtolower ( $_GET['show'] ) == 'stockfit' ) :

          $RESULT	= StockWheelToVechMaxArray (4,GetCurVid(),$_GET['finish'],$_GET['construction'],$_GET['brand'],$_GET['minrim'],$_GET['maxrim'],$_GET['minwidth'],$_GET['maxwidth'],$_GET['minoffset'],$_GET['maxoffset'],$perpage,$_GET['s-page'],$_GET['sort'],$stklimit,$featured ) ;
          $SizeArray	= StockWheelUniqueSizeArrayVechMax (4,GetCurVid(),$_GET['finish'],$_GET['construction'],$_GET['brand'],$_GET['minwidth'],$_GET['maxwidth'],$_GET['minoffset'],$_GET['maxoffset'],$stklimit,$featured ) ;
          $WidthArray 	= StockWheelUniqueWidthArrayVechMax (4,GetCurVid(),$_GET['finish'],$_GET['construction'],$_GET['brand'],$_GET['minrim'],$_GET['maxrim'],$_GET['minoffset'],$_GET['maxoffset'],$stklimit,$featured ) ;
          $OffsetArray 	= StockWheelUniqueOffsetArrayVechMax (4,GetCurVid(),$_GET['finish'],$_GET['construction'],$_GET['brand'],$_GET['minrim'],$_GET['maxrim'],$_GET['minwidth'],$_GET['maxwidth'],$stklimit,$featured ) ;
          $FinishArray 	= StockWheelUniqueFinishArrayVechMax (4,GetCurVid(),$_GET['construction'],$_GET['brand'],$_GET['minrim'],$_GET['maxrim'],$_GET['minwidth'],$_GET['maxwidth'],$_GET['minoffset'],$_GET['maxoffset'],$stklimit,$featured) ;
          $BrandArray 	= StockWheelUniqueBrandArrayVechMax (4,GetCurVid(),$_GET['maxrim'],$_GET['minrim'],$_GET['maxwidth'],$_GET['minwidth'],$_GET['maxoffset'],$_GET['minoffset'],$_GET['finish'],$_GET['construction'],$stklimit,$featured);
      
        else :

          $RESULT	= AdvancedWheelResultArrayVechMax (4,GetCurVid(),$_GET['minrim'],$_GET['maxrim'],$_GET['minwidth'],$_GET['maxwidth'],$_GET['minoffset'],$_GET['maxoffset'],$_GET['finish'],$_GET['construction'],$_GET['brand'],$stklimit,$featured,$perpage,$_GET['s-page'],$_GET['sort']);
          $FinishArray 	= AdvancedWheelUniqueFinishArrayVechMax (4,GetCurVid(),$_GET['minrim'],$_GET['maxrim'],$_GET['minwidth'],$_GET['maxwidth'],$_GET['minoffset'],$_GET['maxoffset'],$_GET['construction'],$_GET['brand'],$stklimit,$featured);
          $BrandArray 	= AdvancedWheelUniqueBrandArrayVechMax (4,GetCurVid(),$_GET['minrim'],$_GET['maxrim'],$_GET['minwidth'],$_GET['maxwidth'],$_GET['minoffset'],$_GET['maxoffset'],$_GET['finish'],$_GET['construction'],$stklimit,$featured);
          $SizeArray	= AdvancedWheelUniqueSizeArrayVechMax (4,GetCurVid(),$_GET['minwidth'],$_GET['maxwidth'],$_GET['minoffset'],$_GET['maxoffset'],$_GET['finish'],$_GET['construction'],$_GET['brand'],$stklimit,$featured);
          $WidthArray 	= AdvancedWheelUniqueWidthArrayVechMax (4,GetCurVid(),$_GET['minrim'],$_GET['maxrim'],$_GET['minoffset'],$_GET['maxoffset'],$_GET['finish'],$_GET['construction'],$_GET['brand'],$stklimit,$featured);
          $OffsetArray 	= AdvancedWheelUniqueOffSetArrayVechMax (4,GetCurVid(),$_GET['minrim'],$_GET['maxrim'],$_GET['minwidth'],$_GET['maxwidth'],$_GET['finish'],$_GET['construction'],$_GET['brand'],$stklimit,$featured) ;

        endif;

      else :

        $storeid 	= 4;
        $bolt 	= $_GET['bc'];
        $minsize 	= $_GET['minrim'];
        $maxsize 	= $_GET['maxrim'];
        $minwidth 	= $_GET['minwidth'];
        $maxwidth 	= $_GET['maxwidth'];
        $minoffset 	= $_GET['minoffset'];
        $maxoffset 	= $_GET['maxoffset'];
        $finish 	= $_GET['finish'];
        $construction = $_GET['construction'];
        $brand 	= $_GET['brand'];
        $invlimitone 	= $stklimit;
        $featurelimit = $featured;
        $curpage 	= $_GET['s-page'];
        $sort 	= $_GET['sort'];

        $BoltArray 	= WheelUniqueBoltArray ( $storeid );

        $RESULT	= WheelResultArrayMax ($storeid,$bolt,$minsize,$maxsize,$minwidth,$maxwidth,$minoffset,$maxoffset,$minhub,$maxhub,$minload,$maxload,$finish,$construction,$brand,$invlimitone,$featurelimit,$perpage,$curpage,$sort);
        $SizeArray	= WheelUniqueSizeArrayMax ($storeid,$bolt,$minwidth,$maxwidth,$minoffset,$maxoffset,$minhub,$maxhub,$minload,$maxload,$finish,$construction,$brand,$invlimitone,$featurelimit);
        $WidthArray 	= WheelUniqueWidthArrayMax ($storeid,$bolt,$minsize,$maxsize,$minoffset,$maxoffset,$minhub,$maxhub,$minload,$maxload,$finish,$construction,$brand,$invlimitone,$featurelimit);
        $FinishArray 	= WheelUniqueFinishArrayMax ($storeid,$bolt,$minsize,$maxsize,$minwidth,$maxwidth,$minoffset,$maxoffset,$minhub,$maxhub,$minload,$maxload,$construction,$brand,$invlimitone,$featurelimit);
        $BrandArray 	= WheelUniqueBrandArrayMax ($storeid,$bolt,$minsize,$maxsize,$minwidth,$maxwidth,$minoffset,$maxoffset,$minhub,$maxhub,$minload,$maxload,$finish,$construction,$invlimitone,$featurelimit);
        $OffsetArray 	= WheelUniqueOffSetArrayMax ($storeid,$bolt,$minsize,$maxsize,$minwidth,$maxwidth,$minhub,$maxhub,$minload,$maxload,$finish,$construction,$brand,$invlimitone,$featurelimit);

      endif;

      echo "
      <form method=get name=search id='vech-search'>
        <div id='search-results'>";

        echo "
        <div id='adv-search-select-boxes' class='toggle-hide'>
        
          <input type='hidden' name='vid' value='".ilif ( is_numeric ( $_GET['vid'] ), true, $_GET['vid'], GetCurVid () )."'>

          <div class='fit-dropdown'>";

        if ( GetCurVid() ) :
          
          echo "
          <input id='auto-pu' type='hidden' name='PU' value='".$_GET['PU']."' />
          
          <select id='fit-options' name='show' OnChange='submit()'>
            <option value='advanced'>Advanced Fitment</option>
            <option value='stockfit'".ilif($_GET['show'],'stockfit',' SELECTED','').">Stock Fitment</option>
          </select>";

          if ( strtolower ( $_GET['show'] ) == 'stockfit' ) :

          echo"
          <div class='fit-disclaimer stock-disclaimer'>
            Results below are based on your OEM specs. If you plan on doing any modifications to your 
            vehicle or want a different width/offset, please use our Advanced Search.
          </div>";

          else :

          echo "
          <div class='fit-disclaimer adv-disclaimer'>
            You may need to do body and/or suspension modification for the below results to fit your vehicle. 
            If you don't plan on doing modification, please use our Stock Search for approved results.
          </div>";

          endif;
      
      else :
      
      echo "
      <select name='bc' OnChange=submit()>
        <option value=''>Bolt Pattern</option>";
        if ( is_array( $BoltArray ) ) :
          foreach($BoltArray as $val ){
            echo " 
            <option value='$val'".ilif($val,$_GET['bc']," SELECTED",'').">$val</option>";
          }
        endif;
      echo "
      </select>";
      
      echo "
      <div class='fit-disclaimer stock-disclaimer'>
        Enter your vehicle above to narrow your results.
      </div>";

      
      endif;

          echo "
          </div>
          <div class='clear'></div>";
          
          if ( strtolower ( $_GET['show'] ) == 'stockfit' ) :
          
          echo "
          <table class='adv-search-select-table' id='stock-fit-table'>

            <tr class='adv-search-select-boxes'>
              <td>
                <select name='minrim' OnChange='DoMinWheel()'>
                  <option value=''>Size</option>";
                  if ( is_array($SizeArray) ):
                    asort($SizeArray);
                    foreach ($SizeArray as $sk=>$size){
                      echo "
                      <option".ilif($_GET['minrim'],$size,' SELECTED','')." value='$size'>$size</option>";
                    }
                  endif;
                echo "
                </select>

                <select name='maxrim' OnChange='DoMaxWheel()' style='display:none';>
                  <option value=''>Max</option>";
                  if ( is_array($SizeArray) ):
                  rsort($SizeArray);
                    foreach ($SizeArray as $sk=>$size){
                      echo "
                      <option".ilif($_GET['maxrim'],$size,' SELECTED','')." value='$size'>$size</option>";
                    }
                  endif;
                echo "
                </select>

                <select name='brand' OnChange='submit()'>
                  <option value=''>Brand</option>";
                    if ( is_array($BrandArray) ):
                      foreach ($BrandArray as $bk=>$brand){
                        echo "
                        <option".ilif($_GET['brand'],$brand,' SELECTED','')." value='$brand'>$brand</option>";
                      }
                  endif;
                echo "
                </select>

                <select name='finish' OnChange='submit()'>
                  <option value=''>Finish</option>";
                  if ( is_array($FinishArray) ):
                    foreach ($FinishArray as $fk=>$finish){
                      echo "
                      <option".ilif($_GET['finish'],$finish,' SELECTED','')." value='$finish'>$finish</option>";
                    }
                  endif;
                echo "
                </select>

                <select name='topsellers' OnChange='submit()'>
                  <option value=''>Availability</option>
                  <option value=''>Everything!</option>";
                  echo"
                  <option".ilif($_GET['topsellers'],'Top Sellers',' SELECTED','')." value='Top Sellers'>Top Sellers</option>
                  <option".ilif($_GET['topsellers'],'Featured',' SELECTED','')." value='Featured'>Featured</option>
                  <option".ilif($_GET['topsellers'],'QuickShip',' SELECTED','')." value='QuickShip'>Quick Ship</option>
                  <option".ilif($_GET['topsellers'],'Blowout',' SELECTED','')." value='Blowout'>Below Blowout!</option>
                </select>
              </td>
            </tr>

          </table>
        </div>";

        else :

          echo "
          <table class='adv-search-select-table' id='adv-fit-table'>

            <tr class='adv-search-select-boxes min-max-selects'>
              <td class='adv-search-select-title'>
                Diameter
              </td>
              
              <td>
                <select name='minrim' OnChange='DoMinWheel()'>
                  <option value=''>Min</option>";
                  if ( is_array($SizeArray) ):
                    asort($SizeArray);
                    foreach ($SizeArray as $sk=>$size){
                      echo "
                      <option".ilif($_GET['minrim'],$size,' SELECTED','')." value='$size'>$size</option>";
                    }
                  endif;
                  echo "
                </select>
                
                
                <select name='maxrim' OnChange='DoMaxWheel()'>
                  <option value=''>Max</option>";
                  if ( is_array($SizeArray) ):
                  rsort($SizeArray);
                    foreach ($SizeArray as $sk=>$size){
                      echo "
                      <option".ilif($_GET['maxrim'],$size,' SELECTED','')." value='$size'>$size</option>";
                    }
                  endif;
                  echo "
                </select>
              </td>
            </tr>
            
            <tr class='adv-search-select-boxes min-max-selects'>
              <td class='adv-search-select-title'>
                Width
              </td>
              
              <td>
                <select name='minwidth' OnChange='DoMinWidth()'>
                  <option value=''>Min</option>";
                  if ( is_array($WidthArray) ):
                  asort($WidthArray);
                    foreach ($WidthArray as $wk=>$width){
                      echo "
                      <option".ilif($_GET['minwidth'],$width,' SELECTED','')." value='$width'>$width</option>";
                    }
                  endif;
                  echo "
                </select>
                    
                <select name='maxwidth' OnChange='DoMaxWidth()'>
                  <option value=''>Max</option>";
                  if ( is_array($WidthArray) ):
                  rsort($WidthArray);
                    foreach ($WidthArray as $wk=>$width){
                      echo "
                      <option".ilif($_GET['maxwidth'],$width,' SELECTED','')." value='$width'>$width</option>";
                    }
                  endif;
                  echo "
                </select>
              </td>
            </tr>
            
            <tr class='adv-search-select-boxes min-max-selects'>
              <td class='adv-search-select-title'>
                Offset
              </td>
              
              <td>
                <select name='minoffset'  OnChange='DoMinOffset()'>
                  <option value=''>Min</option>";
                  if ( is_array($OffsetArray) ):
                  asort($OffsetArray);
                    foreach ($OffsetArray as $ok=>$offset){
                      echo "
                      <option".ilif($_GET['minoffset'],$offset,' SELECTED','')." value='$offset'>".$offset."</option>";
                    }
                  endif;
                  echo "
                </select>

                <select name='maxoffset' OnChange='DoMaxOffset()'>
                  <option value=''>Max</option>";
                  if ( is_array($OffsetArray) ):
                  rsort($OffsetArray);
                    foreach ($OffsetArray as $ok=>$offset){
                      echo "
                      <option".ilif($_GET['maxoffset'],$offset,' SELECTED','')." value='$offset'>".$offset."</option>";
                    }
                  endif;
                  echo "
                </select>
              </td>
            </tr>
            
            <tr class='adv-search-select-boxes other-selects'>
              <td class='adv-search-select-title'>
                &nbsp;
              </td>
              
              <td>
                <select name='brand' OnChange='submit()'>
                  <option value=''>Brand</option>";
                    if ( is_array($BrandArray) ):
                      foreach ($BrandArray as $bk=>$brand){
                        echo "
                        <option".ilif($_GET['brand'],$brand,' SELECTED','')." value='$brand'>$brand</option>";
                      }
                  endif;
                  echo "
                </select>

                <select name='finish' OnChange='submit()'>
                  <option value=''>Finish</option>";
                  if ( is_array($FinishArray) ):
                    foreach ($FinishArray as $fk=>$finish){
                      echo "
                      <option".ilif($_GET['finish'],$finish,' SELECTED','')." value='$finish'>$finish</option>";
                    }
                  endif;
                  echo "
                </select>

                <select name='topsellers' OnChange='submit()'>
                  <option value=''>Availability</option>
                  <option value=''>Everything!</option>";
                  echo"
                    <option".ilif($_GET['topsellers'],'Top Sellers',' SELECTED','')." value='Top Sellers'>Top Sellers</option>
                    <option".ilif($_GET['topsellers'],'Featured',' SELECTED','')." value='Featured'>Featured</option>
                    <option".ilif($_GET['topsellers'],'QuickShip',' SELECTED','')." value='QuickShip'>Quick Ship</option>
                    <option".ilif($_GET['topsellers'],'Blowout',' SELECTED','')." value='Blowout'>Below Blowout!</option>
                </select>
              </td>
            </tr>

          </table>
        </div>";
        
      endif; ?>
          
        <div class="clear"></div>
        
        <hr>
          
        <div class="results-header">
          
          <a href='#' id='filter-button' class='button'>Filter Results</a>

          <h2 class="mobile-page-title"><span class="dt-desc"><strong>WHEEL</strong> SEARCH </span>RESULTS</h2>

          <?php
            $current_page = 1;

            //  if (isset($_GET['s-page']))
            //  $current_page = $_GET['s-page'];

            $current_page = $RESULT['CurPage'];
            $total_shown = $perpage;
            if ($total_shown > $RESULT['Count'])
              $total_shown = $RESULT['Count'];

              if ($total_shown > 0 && !empty($total_shown)) : 

            echo "
            <div id='displaying-results'>

              <div class='results-page-links'>
                Displaying ".$total_shown." of ".$RESULT['Count']." Results | ";

                $max_display = 6;
                $displayed = 0;

                if ($current_page > 3) {
                  echo "...";
                }

                for ($i = max(1, $current_page - 2); $i <= $RESULT['TotalPages']; $i++) : 

                  $displayed++;
                  if ($displayed >= $max_display) break;

                  if ($i == $current_page) : 
                    echo "
                    <a class=\"current\" href='".$_SERVER['request_uri']."?".BuildGetString ('s-page')."&s-page=".$i."'>".$i."</a>";
                  else :
                    echo "
                    <a href='".$_SERVER['request_uri']."?".BuildGetString ('s-page')."&s-page=".$i."'>".$i."</a>"; 
                  endif;
                endfor;

                if ($current_page + 4 <= $RESULT['TotalPages']) {
                  echo "...";
                }
                
              echo "
              </div>

            <select name='sort' OnChange='submit()'>
              <option value=''>Sort</option>
              <option value='1'".ilif($_GET['sort'],'1',' SELECTED','').">Price: Low to High</option>
              <option value='2'".ilif($_GET['sort'],'2',' SELECTED','').">Price: High to Low</option>
              <option value='3'".ilif($_GET['sort'],'3',' SELECTED','').">Diameter: Low to High</option>
              <option value='4'".ilif($_GET['sort'],'4',' SELECTED','').">Diameter: High to Low</option>
              <option value='5'".ilif($_GET['sort'],'5',' SELECTED','').">Width: Low to High</option>
              <option value='6'".ilif($_GET['sort'],'6',' SELECTED','').">Width: High to Low</option>
              <option value='7'".ilif($_GET['sort'],'7',' SELECTED','').">Offset: Low to High</option>
              <option value='8'".ilif($_GET['sort'],'8',' SELECTED','').">Offset: High to Low</option>
              <option value='17'".ilif($_GET['sort'],'17',' SELECTED','').">Name: A to Z</option>
              <option value='18'".ilif($_GET['sort'],'18',' SELECTED','').">Name: Z to A</option>
              <option value='13'".ilif($_GET['sort'],'13',' SELECTED','').">Finish: Low to High</option>
              <option value='14'".ilif($_GET['sort'],'14',' SELECTED','').">Finish: High to Low</option>
              <option value='15'".ilif($_GET['sort'],'15',' SELECTED','').">Brand: A to Z</option>
              <option value='16'".ilif($_GET['sort'],'16',' SELECTED','').">Brand: Z to A</option>
              <option value='9'".ilif($_GET['sort'],'9',' SELECTED','').">HubSize: Low to High</option>
              <option value='10'".ilif($_GET['sort'],'10',' SELECTED','').">HubSize: High to Low</option>
              <option value='11'".ilif($_GET['sort'],'11',' SELECTED','').">Load: Low to High</option>
              <option value='12'".ilif($_GET['sort'],'12',' SELECTED','').">Load: High to Low</option>
            </select>";
          ?>
          </div>
          <div class="clear"></div>
          <?php endif; ?>
          
        </div><!-- results header -->

          <?php
          if ( is_array ( $RESULT['ID'] ) ) {
            foreach ( $RESULT['ID'] as $itemid ) {

              $cat_id = GetFirstCatId ( $itemid );

              $vendorBrand = SmartItemLookup ( 'vendor_brand', $itemid );
              $itemName = SmartItemLookup ( 'item_name', $itemid );
              
              $ProductName = "".$vendorBrand." ".$itemName."";
              
              //$price = GetItemPrice ( $itemid, $storeid );
              $price = CheckPriceSmart ( GetCustId( ) , $itemid );
              
              $Stock = GetStockArray ( $itemid );
              $DC1Stock = $Stock['DC1'];
              $DC2Stock = $Stock['DC2'];
              $DC3Stock = $Stock['DC3'];
              $DC4Stock = $Stock['DC4'];

              if ($DC1Stock == null) {
                $DC1Stock = 0;
              } 
              
              if ($DC2Stock == null) {
                $DC2Stock = 0;
              } 
              
              if ($DC3Stock == null) {
                $DC3Stock = 0;
              } 
              
              if ($DC4Stock == null) {
                $DC4Stock = 0;
              }

              $TotalStock = $DC1Stock + $DC2Stock + $DC3Stock + $DC4Stock; 

              include_once ('inc.store/bk.inc/template/shipping.results.php'); ?>

              <a href="product.php?item_id=<?=$itemid;?>" class="feature-box" style="overflow: visible;">
              
                <?php
                if (GetItemImg ( $itemid, 300 )) {
                  echo "<img class='feature-image' src='../".GetItemImg ( $itemid, 300 )."' alt='".$ProductName."' title='".$ProductName."'>";
                } else {
                  echo "<img class='feature-image' src='inc.store/bk.inc/images/tw-placeholder.png' alt='".$ProductName."' title='".$ProductName."'>";
                } ?>

                <p class="feature-title brand dt-desc"><span><?=$vendorBrand;?><br><?=$itemName;?></span></p>
                <p class="feature-description dt-desc">
                  Size: <?=GetWheelSize ($itemid);?>
                  Offset: <?=AddThePlus (GetWheelSmart ('offset', $itemid));?>
                </p>

                <p class="feature-title brand t-desc"><span><?=$vendorBrand;?><br><?=$itemName;?></span></p>
                <p class="feature-description t-desc">
                  Size: <?=GetWheelSize ($itemid);?><br>
                  Offset: <?=AddThePlus (GetWheelSmart ('offset', $itemid));?>
                </p>

                <p class="feature-title brand m-desc"><span><?=$vendorBrand;?><br><?=$itemName;?></span></p>
                <p class="feature-description m-desc">
                  Size: <?=GetWheelSize ($itemid);?><br>
                  Offset: <?=AddThePlus (GetWheelSmart ('offset', $itemid));?>
                </p>

                <?php
                if (empty($price) || intval($price) == 0) {
                  echo "<p class='feature-price call dt-desc'>Call for Pricing</p>";
                  echo "<p class='feature-price call t-desc'>Call for Pricing</p>";
                  echo "<p class='feature-price call m-desc'>Call<span class='free-shipping'>&nbsp;</span></p>";
                } else {
                  echo "<p class='feature-price'>$".number_format($price, 2, '.', ',')."<span class='free-shipping'>".$ItemShipping."</span></p>";
                } ?>

                <p class="feature-description location-avail dt-desc" style="text-transform:uppercase;">
                  <?php
                  if ($TotalStock <= 3 ) {
                    echo "<span class='red-text'>Low Inventory!</span>";
                  } else {
                    echo "Availability: ".$DC1Stock.", ".$DC2Stock.", ".$DC3Stock.", ".$DC4Stock."";
                  } ?>
                </p>
                <p class="feature-description location-avail t-desc m-desc" style="text-transform:uppercase;line-height:14px;margin-top:10px;">
                  <?php
                  if ($TotalStock <= 3 ) {
                    echo "<span class='red-text'>Low Inventory!</span>";
                  } else {
                    echo "Avail: ".$DC1Stock.", ".$DC2Stock.", ".$DC3Stock.", ".$DC4Stock."";
                  } ?>
                </p>
              </a>

              <?php
            } //  ( $RESULT['ID'] as $itemid ) ?>

            <div class='clear'></div>

            <div class="results-nav">
              <?php
              if ( $RESULT['CurPage'] > 1 ) : ?>
                <a href="<?=$_SERVER['request_uri'];?>?<?=BuildGetString ('s-page');?>&s-page=<?=$RESULT['CurPage']-1;?>" style="float:left;">Previous Page</a>
              <?php else : ?>
                <span class="no-link" style="float:left;">Previous Page</span>
              <?php endif; ?>

              <span>Page <?=$RESULT['CurPage'];?> of <?=$RESULT['TotalPages'];?></span>  
                
              <?php
              if ( $RESULT['TotalPages'] > $RESULT['CurPage'] ) : ?>
                <a href="<?=$_SERVER['request_uri'];?>?<?=BuildGetString ('s-page');?>&s-page=<?=$RESULT['CurPage']+1;?>" style="float:right;">Next Page</a>
              <?php else : ?>
                <span class="no-link" style="float:right;">Next Page</span>
              <?php endif; ?>
            </div>

          <?php
          }	else { // - ( is_array ( $RESULT['ID'] )
            echo "There are no results";
          } ?>

        </div><!--search-results-->
      </form>

    </div><!--twelve-->
    <div class="clear"></div>
  </div><!--row-->
</div>

<?php include 'includes/footer.php'; ?>