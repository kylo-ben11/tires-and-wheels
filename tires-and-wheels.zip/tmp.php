<?php
include_once ('inc.store/ssc.new.api.php');

echo "The Store Id is : ".$storeid."<br>";


if ( is_numeric($_GET['product_id']) ) {
echo "Product Id : ".$_GET['product_id']." <br>Name : "; 
echo GetItemInfoByCode ( $_GET['product_id'], 'Name' )."<br>";
echo " OR <br>";
echo GetItemName ( $_GET['product_id'] )."<br>";
echo " OR <br>";
echo GetItemName ( $_GET['product_id'], $storeid )."<br>";

echo "<img src='".GetItemInfoByCode ( $_GET['product_id'], 'FullImg1' )."'>";
}