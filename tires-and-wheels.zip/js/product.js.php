/* Product Page JavaScript */
<!--
  
function chktodo ( totalvar ) {
  if ( document.cart.amt.value > totalvar ) {
    return false;
  } else {
    return true;
  }
}

function chktodopack ( totalvar ) {
  if ( document.cart.amt_1.value > totalvar ) {
    return false;
  } else {
    return true;
  }
}

function dotocart ( totalvar ) {
  if ( chktodo ( totalvar ) ) {
    document.cart.submit();
  } else {
    jQuery('.backorder-popup').fadeIn(500);	
    jQuery('.popup-mask').fadeIn(800);
    jQuery('.modal').fadeIn(1500);
  }
}

function dotocartLugs ( totalvar ) {
  jQuery('.add-lugs-popup').fadeIn(500);	
  jQuery('.popup-mask').fadeIn(800);
  jQuery('.modal').fadeIn(1500);
}

function dotopack ( totalvar ) {
  if ( chktodopack ( totalvar ) ) {
    window.location.href = ('package.php?item_id='+document.cart.num_1.value);
  } else {
    jQuery('.backorder-pack-popup').fadeIn(500);
    jQuery('.popup-mask').fadeIn(800);
    jQuery('.modal').fadeIn(1500);
  }
}

function cartcontinue () {
  document.cart.submit();
}

function addlugscontinue () {
  cartcontinue();
}

function addlugscontinueFree () {
  document.getElementById('lug-item-id').value = '125905';
  cartcontinue();
}

function addlugscontinueChrome () {
  document.getElementById('lug-item-id').value = '123358';
  cartcontinue();
}

function addlugscontinueBlack () {
  document.getElementById('lug-item-id').value = '145913';
  cartcontinue();
}

function cancellugscontinue () {
  document.getElementById('lug-item-id').value = '123358';
  document.getElementById('lug-qty').value = '0';
  cartcontinue();
}

function packcontinue () {
  window.location.href = ('package.php?item_id='+document.cart.num_1.value);
}

jQuery('#pageload-popup .close').click(function (e) {
  e.preventDefault();
  jQuery('.backorder-popup, .backorder-pack-popup, .add-lugs-popup').fadeOut(500);
});
