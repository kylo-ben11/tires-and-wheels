/* Main Site JavaScript/jQuery */
jQuery(document).ready(function($) {

  //Adds placeholders for browsers that don't support them
  try{
    $('input, textarea').placeholder();
  }catch(err){}

  //Give tel-links 'phone_number' class
  $('a[href^=tel]').each(function(){
    $(this).addClass('phone_number');
  });

  $(window).load(function(){
    $('a[href^=tel]').each(function(){
      $(this).addClass('phone_number');
    });
  });

  //Force Footer to Bottom
	$(document).ready(function() {
		var docHeight = $(window).height();
		var footerHeight = $('#footer').height();
		var footerTop = $('#footer').position().top + footerHeight;
		if (footerTop < docHeight) {
			$('#footer-banner').css('margin-top', 10+ (docHeight - footerTop) + 'px');
		}
	});

  //Mobile Menu Script
  menuOpen = false;
  $('#mobile-menu-button').click(function(){
    if(!menuOpen){
      $('#mobile-menu-wrap, html').addClass('mobile-menu-open');
      menuOpen = true;
    }else{
      $('#mobile-menu-wrap, html').removeClass('mobile-menu-open');
      menuOpen = false;
    }
  });

  $(document).mouseup(function (e)
  {
    var container = $("#mobile-menu-wrap");
    var searchButton = $("#mobile-menu-button");

    if (!container.is(e.target) && !searchButton.is(e.target) && container.has(e.target).length === 0)
    {
      $('#mobile-menu-wrap, html, #mobile-menu-button').removeClass('mobile-menu-open');
      menuOpen = false;
    }
  });
  
  $('#mobile-menu-wrap .close.close-btn.sprite').click(function(e) {
    e.preventDefault();
    $('#mobile-menu-wrap, html, #mobile-menu-button').removeClass('mobile-menu-open');
    menuOpen = false;
  });
  
  //Function that sets the height of the mobile menu and controls/handles scrolling
  //if the menu is too tall for the viewport
  function setMobileMenuHeight(){
      windowHeight = $(window).height();
      documentHeight = $(document).height();
      $('#mobile-menu-wrap').height(documentHeight);
      //Adjust the tailing number below (currently 25) to control distance between the 
      //bottom of the window and the bottom of the mobile menu
      $('#mobile-menu-interior-wrap').css('max-height',windowHeight - 25);
  };
  setMobileMenuHeight();
  $(window).resize(setMobileMenuHeight);

  //App Guide Ajax
  $("#home-year-select").change(function() {
    var year = $("#home-year-select").val();
    $("html").addClass("loading");
    $("#full-screen-loader").css("display", "block");
    $.ajax({
      url: "ajax/make_dropdown.php?year=" + year,
      beforeSend: function( xhr ) {
        xhr.overrideMimeType( "text/plain; charset=x-user-defined" );
      }
    }).done(function(data) {
      $("#home-make-select").html(data);
      $("#home-model-select").html("<option value=\"\">Model</option>");
      $("#home-vid-select").html("<option value=\"\">Sub Model</option>");
      $("html").removeClass("loading");
      $("#full-screen-loader").css("display", "none");
    });
  });

  $("#home-make-select").change(function() {
    var year = $("#home-year-select").val();
    var make = $("#home-make-select").val();
    $("html").addClass("loading");
    $("#full-screen-loader").css("display", "block");
    $.ajax({
      url: "ajax/model_dropdown.php?year=" + year + "&make=" + make,
      beforeSend: function( xhr ) {
        xhr.overrideMimeType( "text/plain; charset=x-user-defined" );
      }
    }).done(function(data) {
      $("#home-model-select").html(data);
      $("#home-vid-select").html("<option value=\"\">Sub Model</option>");
      $("html").removeClass("loading");
      $("#full-screen-loader").css("display", "none");
    });
  });

  $("#home-model-select").change(function() {
    var year = $("#home-year-select").val();
    var make = $("#home-make-select").val();
    var model = $("#home-model-select").val();
    $("html").addClass("loading");
    $("#full-screen-loader").css("display", "block");
    $.ajax({
      url: "ajax/submodel_dropdown.php?year=" + year + "&make=" + make + "&model=" + model,
      beforeSend: function( xhr ) {
          xhr.overrideMimeType( "text/plain; charset=x-user-defined" );
      }
    }).done(function(data) {
      $("#home-vid-select").html(data);
      $("html").removeClass("loading");
      $("#full-screen-loader").css("display", "none");
    });
  });

  $('#home-vid-select').change(function() {
    if(!$(this).val()) return;
    $("html").addClass("loading");
    $("#full-screen-loader").css("display", "block");
    $(this).closest('form').submit();
  });

  $("#advanced-search-button").click(function() {
      $("#advanced-search-form").submit();
      return false;
  });
  
  //SubCat Table Links
  $('.link-row').click(function() {
    window.location.href = $(this).find('a').attr('href');
  });

  //Tire Search
  // var size_or_od = function() {
    // var is_csas = ($(this).val()==='csas');
    // $('[name=minod],[name=maxod]').prop('disabled',is_csas);
    // $('[name=aspect],[name=cross]').prop('disabled',!is_csas);
  // }
  // size_or_od.apply(
    // $('[name=size-or-od]').change(size_or_od).filter('[checked]')
  // );
  
  //Product Details Toggle
  $(".see-more-btn.wt-step-1-btn").click(function(){
    $(".toggle-hide.pbs1").fadeToggle(500);
    return false;
  });

  $(".see-more-btn.wt-step-2-btn").click(function(){
    $(".toggle-hide.pbs2").fadeToggle(500);
    return false;
  });

  //Product Page - Lugs Count
  var LugMultiplier = 1;

  $("#lug-per-wheel").on("keyup change", function() {
    var value = this.value;
    var valuemath = value * LugMultiplier;  
    $("#lug-qty").val(valuemath);   
  });

  $('#wheel-qty').change(function(){
    LugMultiplier = $(this).val();
    $("#lug-per-wheel").trigger("keyup");
    $("#tpms-qty").val(LugMultiplier);
 });

  //App Guide Target Button
  (function(click_to_target, target) {
    if(!(click_to_target.length && target.length)) return;

    click_to_target.click(function(e) {
      e.preventDefault();
      target.find('select:has(option[value=""]:selected)').first().addClass('highlight');
    });

    target.find('select').click(function() {
      $(this).removeClass('highlight');
    });

  }($('[data-role=target-app-guide]'),$('#select-boxes')));

  //Search Results Popup
	$(document).ready(function() {
    $('.wheel-search-pu1, .register-pu').fadeIn(100);
    $('.popup-mask').fadeIn(800);	
    $('.modal').fadeIn(1500);
	});

	$('#make-offer-btn').click(function() {
    $('.make-offer-popup').fadeIn(100);	
    $('.popup-mask').fadeIn(800);	
    $('.modal').fadeIn(1500);
	});

  $('#pageload-popup .close, #siteload-popup .close').click(function (e) {
    e.preventDefault();
    $('.wheel-search-pu1, .wheel-search-pu2, .backorder-popup, .backorder-pack-popup, .make-offer-popup, .rv-comment-pu, .register-pu, .not-confirmed-pu, .add-lugs-popup').fadeOut(500);
  });

  function displayFilterButton(){
    if($(window).scrollTop() > 300){
      $('#filter-button').css("right","0px");
    }else{
      $('#filter-button').css("right","-300px");
    }
  }
  displayFilterButton();
  $(window).scroll(displayFilterButton);

  $('#filter-button').click(function (e) {
    e.preventDefault();
    $("html, body").animate({ scrollTop:0 },"slow");
  });

  $('#adv-fitment-button').click(function () {
    document.search.PU.value = 1;
    $('#fit-options').val('advanced').trigger('change');
  });
    
  $('#stock-fitment-button').click(function () {
    document.search.PU.value = 1;
    $('#fit-options').val('stockfit').trigger('change');
  });
  
  //Remove item from Cart
  $(".remove-btn.xtra").click(function(e) {
    var nid = $(this).attr("data-nid");
    var selector = "input[name='n_" + nid + "']";

    $("input[name='n_" + nid + "']").val(0);
    $("input[name='n_" + nid + "']").next(".update-btn").click();
  });

  //Email Match Check
  $(document).ready(function() {
    $("#email2").keyup(confirmEmail);
  });

  function confirmEmail() {
    var email1 = $("#email1").val();
    var email2 = $("#email2").val();

    if(email1 == email2) {
      $("#validate-email-status").css("display", "none");
      $(".email").css("border-color", "#b3b3b3");
    } else {
      $("#validate-email-status").css("display", "block");  
      $("#validate-email-status").text("Emails Must Match");
      $(".email").css("border-color", "#ff0000");
    }
  }


});

function validateOffer() {
  var a=document.forms["makeoffer"]["name"].value;
  var b=document.forms["makeoffer"]["email"].value;
  var c=document.forms["makeoffer"]["phone"].value;
  var d=document.forms["makeoffer"]["qun"].value;
  var e=document.forms["makeoffer"]["each"].value;
  var error=document.querySelector("#offer-form-error");
  
  if (a==null || a=="",b==null || b=="",c==null || c=="",d==null || d=="",e==null || e=="") {
    // alert("Please Fill All Required Field");  
    error.style.display = "block";
    return false;
  } else {
    error.style.display = "none";
    document.makeoffer.submit();
  }
}

//Make Offer Captcha
function refreshCaptchatwo() {
  var img = document.images['captchatwoimg'];
  img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
}

function dosubmit_makeoffer() {
  if ( validateOffer() ) {
    document.makeoffer.submit();
  }
}

//Giveaway Ticket Form
function enableBtn(){
  document.getElementById("submit-button").disabled = false;
}

function chk_captchatwo() {
  var Val1=document.makeoffer.captcha
  var capError=document.querySelector("#captcha-form-error");

  if((Val1.value==null)||(Val1.value=="")||(Val1=='Captcha*')) {
    // alert('Captcha Can Not Be Blank')
    capError.style.display = "block";
    Val1.focus()
    return false
  } else {
    capError.style.display = "none";
  }
  return true
}

// Checkout Form Validation
function validateFName() {
  var fname = document.forms["payment-form"]["firstname"].value;
  if (fname == null || fname == "") {
    document.getElementById("fname-error").innerHTML="First Name can't be blank";
    jQuery(".name.fname").css("border-color", "#ff0000");
    return false;
  } else {
    document.getElementById("fname-error").innerHTML="";
    jQuery(".name.fname").css("border-color", "#b3b3b3");
  }
}

function validateLName() {
  var lname = document.forms["payment-form"]["lastname"].value;
  if (lname == null || lname == "") {
    document.getElementById("lname-error").innerHTML="Last Name can't be blank";
    jQuery(".name.last").css("border-color", "#ff0000");
    return false;
  } else {
    document.getElementById("lname-error").innerHTML="";
    jQuery(".name.last").css("border-color", "#b3b3b3");
  }
}

function validateAddress() {
  var address = document.forms["payment-form"]["street"].value;
  if (address == null || address == "") {
    document.getElementById("address-error").innerHTML="Address can't be blank";
    jQuery(".address").css("border-color", "#ff0000");
    return false;
  } else {
    document.getElementById("address-error").innerHTML="";
    jQuery(".address").css("border-color", "#b3b3b3");
  }
}

function validateCity() {
  var city = document.forms["payment-form"]["city"].value;
  if (city == null || city == "") {
    document.getElementById("city-error").innerHTML="City can't be blank";
    jQuery(".city").css("border-color", "#ff0000");
    return false;
  } else {
    document.getElementById("city-error").innerHTML="";
    jQuery(".city").css("border-color", "#b3b3b3");
  }
}

function validateState() {
  var state = document.forms["payment-form"]["state"].value;
  if (state == null || state == "") {
    document.getElementById("state-error").innerHTML="State can't be blank";
    jQuery(".state").css("border-color", "#ff0000");
    return false;
  } else {
    document.getElementById("state-error").innerHTML="";
    jQuery(".state").css("border-color", "#b3b3b3");
  }
}

function validateZip() {
  var zip = document.forms["payment-form"]["zip"].value;
  if (zip == null || zip == "") {
    document.getElementById("zip-error").innerHTML="Zip can't be blank";
    jQuery(".zip").css("border-color", "#ff0000");
    return false;
  } else {
    document.getElementById("zip-error").innerHTML="";
    jQuery(".zip").css("border-color", "#b3b3b3");
  }
}

function validateEmail() {
  var email = document.forms["payment-form"]["email"].value;
  if (email == null || email == "") {
    document.getElementById("email-error").innerHTML="Email can't be blank";
    jQuery(".email").css("border-color", "#ff0000");
    return false;
  } else {
    document.getElementById("email-error").innerHTML="";
    jQuery(".email").css("border-color", "#b3b3b3");
  }
}

function validatePhone() {
  var phone = document.forms["payment-form"]["cust_phone"].value;
  if (phone == null || phone == "") {
    document.getElementById("phone-error").innerHTML="Phone can't be blank";
    jQuery(".phone").css("border-color", "#ff0000");
    return false;
  } else {
    document.getElementById("phone-error").innerHTML="";
    jQuery(".phone").css("border-color", "#b3b3b3");
  }
}

function validateCC() {
  var ccnum = document.forms["payment-form"]["ccnum"].value;
  if (ccnum == null || ccnum == "") {
    document.getElementById("cc-error").innerHTML="Credit Card Number can't be blank";
    jQuery("#cn").css("border-color", "#ff0000");
    return false;
  } else {
    document.getElementById("cc-error").innerHTML="";
    jQuery("#cn").css("border-color", "#b3b3b3");
  }
}

function validateExpMonth() {
  var expmonth = document.forms["payment-form"]["expmonth"].value;
  if (expmonth == null || expmonth == "") {
    document.getElementById("expmonth-error").innerHTML="Expiration Month can't be blank";
    jQuery(".exp-month").css("border-color", "#ff0000");
    return false;
  } else {
    document.getElementById("expmonth-error").innerHTML="";
    jQuery(".exp-month").css("border-color", "#b3b3b3");
  }
}

function validateExpYear() {
  var expyear = document.forms["payment-form"]["expyear"].value;
  if (expyear == null || expyear == "") {
    document.getElementById("expyear-error").innerHTML="Expiration Year can't be blank";
    jQuery(".exp-year").css("border-color", "#ff0000");
    return false;
  } else {
    document.getElementById("expyear-error").innerHTML="";
    jQuery(".exp-year").css("border-color", "#b3b3b3");
  }
}

function validateCVV() {
  var cvv = document.forms["payment-form"]["cvv"].value;
  if (cvv == null || cvv == "") {
    document.getElementById("cvv-error").innerHTML="CVV can't be blank";
    jQuery(".cvv").css("border-color", "#ff0000");
    return false;
  } else {
    document.getElementById("cvv-error").innerHTML="";
    jQuery(".cvv").css("border-color", "#b3b3b3");
  }
}
