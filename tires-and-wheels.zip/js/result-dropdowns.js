function DoSubmit() {
  $("html").addClass("loading");
  $("#full-screen-loader").css("display", "block");
  document.search.submit();
}

function DoMinWheel ( ) {
  if ( Number(document.search.maxrim.value) < Number(document.search.minrim.value) ) {
    if ( document.search.maxrim.value != '' ) {
      document.search.maxrim.value = document.search.minrim.value;
    }
  }
  if ( document.search.maxrim.value == '' ) {
    document.search.maxrim.value = document.search.minrim.value;
  }
  document.search.submit();
}

function DoMaxWheel ( ) {
  if ( Number(document.search.maxrim.value) < Number(document.search.minrim.value) ) {
    if ( document.search.minrim.value != '' ) {
      if ( document.search.maxrim.value != '' ) {
        document.search.minrim.value = document.search.maxrim.value;
      }
    }
  }
  document.search.submit();
}

function DoMinWidth ( ) {
  if ( Number(document.search.maxwidth.value) < Number(document.search.minwidth.value) ) {
    if ( document.search.maxwidth.value != '' ) {
      document.search.maxwidth.value = document.search.minwidth.value;
    }
  }
  if ( document.search.maxwidth.value == '' ) {
    document.search.maxwidth.value = document.search.minwidth.value;
  }
  document.search.submit();
}

function DoMaxWidth ( ) {
  if ( Number(document.search.maxwidth.value) < Number(document.search.minwidth.value) ) {
    if ( document.search.minwidth.value != '' ) {
      if ( document.search.maxwidth.value != '' ) {
        document.search.minwidth.value = document.search.maxwidth.value;
      }
    }
  }
  document.search.submit();
}

function DoMinOffset ( ) {
  if ( document.search.maxoffset.value < document.search.minoffset.value ) {
    if ( document.search.maxoffset.value != '' ) {
      document.search.maxoffset.value = document.search.minoffset.value;
    }
  }
  if ( document.search.maxoffset.value == '' ) {
    document.search.maxoffset.value = document.search.minoffset.value;
  }
  document.search.submit();
}

function DoMaxOffset ( ) {
  if ( document.search.maxoffset.value < document.search.minoffset.value ) {
    if ( document.search.minoffset.value != '' ) {
      if ( document.search.maxoffset.value != '' ) {
        document.search.minoffset.value = document.search.maxoffset.value;
      }
    }
  }
  document.search.submit();
}

function DoMinOD ( ) {
  if ( document.search.maxod.value < document.search.minod.value ) {
    if ( document.search.maxod.value != '' ) {
      document.search.maxod.value = document.search.minod.value;
    }
  }
  if ( document.search.maxod.value == '' ) {
    document.search.maxod.value = document.search.minod.value;
  }
  document.search.submit();
}

function DoMaxOD ( ) {
  if ( document.search.maxod.value < document.search.minod.value ) {
    if ( document.search.minod.value != '' ) {
      if ( document.search.maxod.value != '' ) {
        document.search.minod.value = document.search.maxod.value;
      }
    }
  }
  document.search.submit();
}





function DoPage ( id ) {
  document.search.page.value = id ;
  document.search.submit();
}