<?php
$Page = 'contact';
$PageClass = 'contact-page';
$HeroTitle = 'Contact Us';

$AddJs[0] = 'https://www.google.com/recaptcha/api.js';
include 'includes/mail-contact.php';
include 'includes/header.php';
include ('includes/app-guide.php');
?>

<div class="container" id="main">
  <div class="row">
    <?php
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
      
      echo "<div class='centered'>";
      echo "<h2>Thank you for getting in touch!</h2>";
      echo "<p>Our goal is your satisfaction and we won't settle for less! We appreciate your business.</p>";
      echo "<h4>Thanks again from all of us at TiresAndWheels.com!</h4>";
      echo "</div>";

    } else { ?>

    <div class="twelve last">
      <h2>Questions, Comments or Suggestions?!</h2>
      <p>Please let us know. We love to hear feedback from you!</p>
    </div>
    
    <div class="clear"></div>
    
    <div class="eight">
      <form name="contact" action="" method="post" class="contact-form">
        <label for="name">Name</label>
        <input type="text" name="name" placeholder="" id="contact-name" required />
        <br>
        <label for="email">Email</label>
        <input type="email" name="email" placeholder="you@example.com" id="contact-email" required />
        <br>
        <label for="phone">Phone Number</label>
        <input type="tel" name="phone" placeholder="888-258-4737" id="contact-phone" />
        <br>
        <label for="message">Message</label>
        <textarea name="message" rows="6" placeholder="" id="contact-message" required /></textarea>
        <br>
        <input type=hidden name='recaptcha' value='google'>
        <div class="g-recaptcha" data-sitekey="6Lce6g8TAAAAAB477lzCNgxijzvuzR6SOMMTA8n1" data-callback="enableBtn"></div>
        <br>

        <button id="submit-button" class="submit-form button" name="submit-form" type="submit" disabled>Send Message</button>
      </form>
    </div>
    
    <div class="location-info four last">

      <div class="loc-item">
        <div class="loc-info">
          <h3>Call us : <a href="tel:8882584737">888-258-4737</a></h3>
          <a href="mailto:info@tiresandwheels.com">info@tiresandwheels.com</a>
        </div>
        <div class="clear"></div>
      </div>

      <div class="loc-item">
        <div class="loc-info">
          <h3>Appleton</h3>
          Tire Reps | Extreme Customs<br>
          <a href="https://goo.gl/maps/tX1fEVWeWW62" target="_blank">
          5013 W Greenville Drive<br>
          Appleton, Wisconsin 54913</a>
        </div>
        <div class="clear"></div>
      </div>

      <div class="loc-item">
        <div class="loc-info">
          <h3>Oshkosh</h3>
          Tire Reps | Extreme Customs<br>
          <a href="https://goo.gl/maps/8ajqztAfdxn" target="_blank">
          3420 Jackson St. Suite A<br>
          Oshkosh, WI 54901</a>
        </div>
        <div class="clear"></div>
      </div>

      <div class="loc-item">
        <div class="loc-info">
          <h3>Wautoma</h3>
          Tire Reps | Extreme Auto Sales<br>
          <a href="https://goo.gl/maps/taxTLmYEuwp" target="_blank">
          W. 7627 Highway 21 & 73<br>
          Wautoma, WI 54982</a>
        </div>
        <div class="clear"></div>
      </div>

    </div>

    <div class="clear"></div>

    <?php } ?>

    <div class="page-pic-bottom">
      <img src="../inc.store/bk.inc/tirereps/images/location-oshkosh.jpg" alt="Contact Tire Reps" />
    </div>
  
  </div>
</div>

<?php
include 'includes/footer.php';
?>