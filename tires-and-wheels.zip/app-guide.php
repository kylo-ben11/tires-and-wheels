<?php
function get_hidden_inputs($except) {
  $o = '';
  foreach($_GET as $k => $v) {
    if(in_array($k, $except)) continue;
    $o .= '<input type="hidden" name="'.$k.'" value="'
      .htmlspecialchars($v, ENT_QUOTES)
      .'">';
  }
  return $o;
}

$vid = GetCurVid();
if(!isset($appguide_prompt)) {
  $appguide_prompt = 'Let&#39;s Get Rolling! Start Here';
}

if(!isset($appguide_action)) {
  $appguide_action = '';
}

if(!isset($appguide_reset)) {
  $appguide_reset = '?c-vid=0';
}

if($vid):
?>

<div class="container" id="search-vehicle">
  <div class="row">
    <div class="twelve last">
      <?php
        $cyear  = GetModelYear($vid);
        $cmake  = GetModelMake($vid);
        $cmodel = GetModelName($vid);
        $csub   = GetModelSub($vid);

        $full_name = $cyear . " " . $cmake . " " . $cmodel . " " . $csub;
      ?>
      <div id="search-vehicle-text">
        <span id="vid-str">
          <strong>VEHICLE:</strong>
          <?=$full_name;?>
          <a href="<?=$appguide_reset;?>">[reset vehicle]</a>
        </span>
        <span id="show-form"><a href="#">Filter Results</a></span>
      </div>
    </div>
    <div class="clear"></div>
  </div>
</div>

<?php
elseif(!(isset($appguide_show_only_if_set) && $appguide_show_only_if_set)):
?>

<div id="advanced-search" class="container">
  <div class="row">
    <div id="advanced-search-title"><?=$appguide_prompt;?></div>
    <div id="select-boxes">
        <form id="advanced-search-form" action="<?=$appguide_action;?>" method="get">
        
          <?php
          if ( is_numeric( $_GET['item_id'] ) ): 
            echo " 
            <input type=hidden name='item_id' value='".$_GET['item_id']."'>";
          endif;

          if ( is_numeric( $_GET['cat_id'] ) ): 
            echo " 
            <input type=hidden name='cat_id' value='".$_GET['cat_id']."'>";
          endif;

          if ( is_numeric( $_GET['scat_id'] ) ): 
            echo " 
            <input type=hidden name='scat_id' value='".$_GET['scat_id']."'>";
          endif;
          ?>

          <?php
            $yeararry = GetYearArray();
          ?>
          <select id="home-year-select" name="c-year"><option value="">Year</option>
          <?php
            if(is_array($yeararry)){
              foreach($yeararry as $year) {
                echo "<option value='".$year."'".ilif($_GET['year'],$year," SELECTED",'').">".$year."</option>";
              }
            }
          ?>
          </select>
          <select id="home-make-select" name="c-make"><option value="">Make</option></select>
          <select id="home-model-select" name="c-model"><option value="">Model</option></select>
          <select id="home-vid-select" name="c-vid"><option value="">Sub Model</option></select>
        </form>
      <?php/*<div id="wheel-tire-brand"><?php echo ilif($PAGENAME,'brands','','<a href="brands.php">click here</a> to shop by brand') ?></div>*/?>
    </div>
    <div class="clear"></div>
  </div>
</div>


<?php
endif
?>
